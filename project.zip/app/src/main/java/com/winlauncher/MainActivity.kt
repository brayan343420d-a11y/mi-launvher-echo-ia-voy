package com.winlauncher

import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.StateListDrawable
import android.hardware.display.DisplayManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.util.DisplayMetrics
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Choreographer
import android.view.Display
import android.view.Gravity
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.random.Random

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_IMAGE = 1
private const val REQ_VIDEO = 2
private const val REQ_SHORTCUT = 3
private const val REQ_ICON = 4
private const val REQ_BIND = 5
private const val REQ_WCONFIG = 6
private const val REQ_BADGE = 7
private const val ANIM_MS = 200L
private const val DEFAULT_BG = 0xFF429C92.toInt()

/**
 * Un icono del escritorio.
 * kind 0 = app (pkg + cls), 1 = acceso directo con Intent (data), 2 = acceso directo fijado por una app (pkg + cls = id del shortcut).
 * fx/fy = posición como fracción (0..1) del espacio libre de la página.
 */
class Pin(var kind: Int, val pkg: String, val cls: String) {
    var fx = 0f
    var fy = 0f
    var page = 0
    var label: String? = null
    var data: String? = null
    var base: String? = null   // icono original guardado (accesos directos)
    var custom: String? = null // icono elegido por el usuario (PNG con transparencia, etc.)
    var widgetId = -1          // kind 3 = widget
    var ww = 40                // ancho del widget en % del escritorio
    var wh = 30                // alto del widget en % del escritorio
}

/** Último programa abierto en ventana: sirve para volver a pedirle su tamaño cuando se gira la tablet. */
class Launch(val pkg: String, val game: Boolean, val go: (Bundle?) -> Unit)

class AppItem(val label: String, val pkg: String, val cls: String, val icon: Drawable)

class MItem(val label: String, val action: () -> Unit)

fun drawableToBitmap(d: Drawable, size: Int): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    d.setBounds(0, 0, size, size)
    d.draw(c)
    return bmp
}

/** Escritorio: coloca cada hijo según su Pin y detecta el deslizamiento entre páginas. */
class Desktop(ctx: Context) : FrameLayout(ctx) {
    var onSwipe: ((Int) -> Unit)? = null
    var swipeBlocked = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val minSwipe = 72 * ctx.resources.displayMetrics.density
    private var sx = 0f
    private var sy = 0f

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_MOVE && !swipeBlocked) {
            val dx = ev.x - sx
            val dy = ev.y - sy
            if (abs(dx) > slop * 3 && abs(dx) > abs(dy) * 1.5f) return true
        }
        return false
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            sx = ev.x
            sy = ev.y
            swipeBlocked = false
        }
        val r = super.dispatchTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP && !swipeBlocked) {
            val dx = ev.x - sx
            val dy = ev.y - sy
            if (abs(dx) > minSwipe && abs(dx) > abs(dy) * 1.5f) onSwipe?.invoke(if (dx < 0) 1 else -1)
        }
        return r
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val w = measuredWidth
        val h = measuredHeight
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val pin = v.tag as? Pin ?: continue
            if (pin.kind == 3) {
                v.measure(
                    View.MeasureSpec.makeMeasureSpec(w * pin.ww / 100, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(h * pin.wh / 100, View.MeasureSpec.EXACTLY)
                )
            }
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val pin = v.tag as? Pin ?: continue
            val w = v.measuredWidth
            val h = v.measuredHeight
            val x = (pin.fx * (width - w)).toInt().coerceAtLeast(0)
            val y = (pin.fy * (height - h)).toInt().coerceAtLeast(0)
            v.layout(x, y, x + w, y + h)
        }
    }
}

/** Puntitos que indican en qué página estás. */
class PageDots(ctx: Context) : View(ctx) {
    private var count = 1
    private var index = 0
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(c: Int, i: Int) {
        count = c
        index = i
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val gap = 14 * d
        val x0 = width / 2f - (count - 1) * gap / 2f
        for (i in 0 until count) {
            p.color = if (i == index) 0xFFFFFFFF.toInt() else 0x66FFFFFF
            cv.drawCircle(x0 + i * gap, height / 2f, if (i == index) 3.5f * d else 3f * d, p)
        }
    }
}

/**
 * Física ligera para arrastrar iconos: el icono "flota" un poco detrás del dedo y se inclina como si el aire
 * lo empujara; al soltarlo vuelve a su sitio con un balanceo suave. Solo resortes, sin librerías externas.
 */
class AirDrag(private val v: View, private val d: Float) : Choreographer.FrameCallback {
    private var tx = 0f
    private var ty = 0f
    private var vx = 0f
    private var vy = 0f
    private var rot = 0f
    private var vr = 0f
    private var sc = 1f
    private var vs = 0f
    private var holding = false
    private var running = false
    private var last = 0L

    fun grab() {
        holding = true
        kick()
    }

    fun release() {
        holding = false
        kick()
    }

    /** El destino del icono se movió (dx, dy) píxeles: el icono se queda un poco atrás y los resortes lo alcanzan. */
    fun moved(dx: Float, dy: Float) {
        val m = 56f * d
        tx = (tx - dx).coerceIn(-m, m)
        ty = (ty - dy).coerceIn(-m, m)
        kick()
    }

    private fun kick() {
        if (running) return
        running = true
        last = 0L
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun rest() {
        v.translationX = 0f
        v.translationY = 0f
        v.rotation = 0f
        v.scaleX = 1f
        v.scaleY = 1f
    }

    private fun step(h: Float) {
        // posición: resorte amortiguado hacia el dedo
        vx += (-170f * tx - 19f * vx) * h
        vy += (-170f * ty - 19f * vy) * h
        tx += vx * h
        ty += vy * h
        // inclinación: sigue al retraso del icono, con balanceo (poco amortiguada)
        val target = (tx / d * 0.4f).coerceIn(-16f, 16f)
        vr += (-130f * (rot - target) - 7f * vr) * h
        rot += vr * h
        // se levanta al agarrarlo y rebota un poco al soltarlo
        val st = if (holding) 1.1f else 1f
        vs += (-260f * (sc - st) - 16f * vs) * h
        sc += vs * h
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!v.isAttachedToWindow) {
            running = false
            rest()
            return
        }
        var dt = if (last == 0L) 1f / 60f else (frameTimeNanos - last) / 1_000_000_000f
        last = frameTimeNanos
        if (dt > 1f / 30f) dt = 1f / 30f
        val h = dt / 2f
        step(h)
        step(h)
        v.translationX = tx
        v.translationY = ty
        v.rotation = rot
        v.scaleX = sc
        v.scaleY = sc
        val still = !holding && abs(tx) < 0.4f && abs(ty) < 0.4f && abs(vx) < 4f && abs(vy) < 4f &&
            abs(rot) < 0.25f && abs(vr) < 3f && abs(sc - 1f) < 0.004f && abs(vs) < 0.06f
        if (still) {
            running = false
            last = 0L
            rest()
        } else {
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
}

/** Fondo de video con audio, recortado para llenar la pantalla. Se libera por completo al salir del launcher. */
class VideoBackground(ctx: Context) : TextureView(ctx), TextureView.SurfaceTextureListener {
    private var player: MediaPlayer? = null
    private var surface: Surface? = null
    private var uri: Uri? = null
    private var muted = false
    private var vw = 0
    private var vh = 0

    init {
        surfaceTextureListener = this
    }

    fun setSource(u: Uri?, mute: Boolean) {
        release()
        uri = u
        muted = mute
        if (u != null) startPlayback()
    }

    fun setMuted(m: Boolean) {
        muted = m
        val v = if (m) 0f else 1f
        try {
            player?.setVolume(v, v)
        } catch (_: Exception) {
        }
    }

    fun startPlayback() {
        val u = uri ?: return
        val s = surface ?: return
        if (player != null) return
        try {
            val p = MediaPlayer()
            player = p
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            )
            p.setDataSource(context, u)
            p.setSurface(s)
            p.isLooping = true
            val v = if (muted) 0f else 1f
            p.setVolume(v, v)
            p.setOnVideoSizeChangedListener { _, w, h ->
                vw = w
                vh = h
                fit()
            }
            p.setOnPreparedListener { it.start() }
            p.setOnErrorListener { _, _, _ ->
                release()
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            release()
        }
    }

    fun stopPlayback() {
        release()
    }

    private fun release() {
        val p = player
        player = null
        if (p != null) {
            try {
                p.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun fit() {
        if (vw == 0 || vh == 0 || width == 0 || height == 0) return
        val s = maxOf(width.toFloat() / vw, height.toFloat() / vh)
        val m = Matrix()
        m.setScale(vw * s / width, vh * s / height, width / 2f, height / 2f)
        setTransform(m)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        surface = Surface(st)
        startPlayback()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
        fit()
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        release()
        surface?.release()
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
}

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var bgImage: ImageView
    private lateinit var bgVideo: VideoBackground
    private lateinit var column: LinearLayout
    private lateinit var desktop: Desktop
    private lateinit var dots: PageDots
    private lateinit var bgLayer: FrameLayout
    private lateinit var scrim: View

    private var curSlot = 1        // qué fondo (1 o 2) se está mostrando
    private var editSlot = 1       // qué fondo se está editando en Ajustes
    private var justCreated = true
    private var skipRandom = false // true cuando salimos a un selector/ajuste del sistema y volvemos
    private var badgeBmp: Bitmap? = null
    private var badgeKey = "?"
    private val ease = PathInterpolator(0.2f, 0f, 0f, 1f)

    private var lastLaunch: Launch? = null // último abierto EN VENTANA (para reacomodarlo al girar)
    private var lastPkg: String? = null    // último abierto desde el launcher (para el diagnóstico)
    private var lastRect: Rect? = null     // rectángulo con el que se abrió (null = pantalla completa)
    private var lastLand = false
    private val rotHandler = Handler(Looper.getMainLooper())
    private var rotPending = false
    @Volatile
    private var rotGen = 0       // cada giro lanza un intento nuevo; los intentos viejos se cancelan solos
    @Volatile
    private var rotLog = ""      // qué pasó en el último reacomodo (se ve en el diagnóstico)
    private val rotRun = Runnable {
        rotPending = false
        onRotated()
    }
    private val rotReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            scheduleRotateFix()
        }
    }

    // Segundo aviso de giro, más fiable que el anterior: llega aunque el launcher esté detrás de la ventana del juego.
    private val rotDisplay = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY && realLandscape() != lastLand) scheduleRotateFix()
        }
    }

    private val pins = ArrayList<Pin>()
    private var pageCount = 1
    private var currentPage = 0
    private var popup: PopupWindow? = null
    private var dialog: AlertDialog? = null
    private var pendX = 0f
    private var pendY = 0f
    private var iconPin: Pin? = null
    private var winCount = 0
    private var frozen = false
    private var sawBlur = false
    private var fpsHinted = false
    private var wId = -1
    private var wInfo: AppWidgetProviderInfo? = null

    private val awm: AppWidgetManager by lazy { AppWidgetManager.getInstance(this) }
    private val host: WinHost by lazy { WinHost(applicationContext) }

    private val pm: PackageManager get() = packageManager

    // ───────────────────────── ciclo de vida ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("wl", MODE_PRIVATE)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        loadPins()
        buildUi()
        lastLand = realLandscape()
        try {
            val f = IntentFilter(Intent.ACTION_CONFIGURATION_CHANGED)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(rotReceiver, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(rotReceiver, f)
        } catch (_: Exception) {
        }
        try {
            getSystemService(DisplayManager::class.java).registerDisplayListener(rotDisplay, rotHandler)
        } catch (_: Exception) {
        }
        curSlot =if (randomOn() && hasSlot2() && Random.nextBoolean()) 2 else 1
        applyBackground(curSlot)
        if (animsOn()) {
            bgLayer.alpha = 0f
            bgLayer.animate().alpha(1f).setDuration(450).setInterpolator(ease).start()
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            host.startListening()
        } catch (_: Exception) {
        }
        consumePending()
        refreshDesktop()
        val first = justCreated
        val skip = first || skipRandom
        justCreated = false
        skipRandom = false
        if (!first) {
            bgLayer.animate().cancel()
            bgLayer.alpha = 1f
        }
        // Con dos fondos y "alternar al azar", cada vez que vuelves al launcher puede salir uno distinto
        if (!skip && randomOn() && hasSlot2()) {
            val next = if (Random.nextBoolean()) 1 else 2
            if (next != curSlot) {
                switchBackground(next)
                return
            }
        }
        if (frozen) {
            unfreezeBackground()
        } else {
            bgVideo.startPlayback()
            (bgImage.drawable as? AnimatedImageDrawable)?.start()
        }
    }

    /** Cuando un juego (en ventana) toma el foco, el fondo ya está congelado; al volver al launcher se reanuda. */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!frozen) return
        if (!hasFocus) sawBlur = true else if (sawBlur) unfreezeBackground()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && frozen && !sawBlur) unfreezeBackground()
        return super.dispatchTouchEvent(ev)
    }

    override fun onStop() {
        super.onStop()
        try {
            host.stopListening()
        } catch (_: Exception) {
        }
        bgVideo.stopPlayback()
        (bgImage.drawable as? AnimatedImageDrawable)?.stop()
        popup?.dismiss()
    }

    override fun onDestroy() {
        rotGen++
        rotHandler.removeCallbacks(rotRun)
        try {
            unregisterReceiver(rotReceiver)
        } catch (_: Exception) {
        }
        try {
            getSystemService(DisplayManager::class.java).unregisterDisplayListener(rotDisplay)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        popup?.dismiss()
        dialog?.dismiss()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        scheduleRotateFix()
    }

    override fun onBackPressed() {
        // Un launcher no se cierra con "atrás"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_BIND) {
            if (resultCode == RESULT_OK) configureWidget() else cancelWidget()
            return
        }
        if (requestCode == REQ_WCONFIG) {
            if (resultCode == RESULT_OK) finishWidget() else cancelWidget()
            return
        }
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == REQ_BADGE) {
            handleBadgeResult(data)
            return
        }
        if (requestCode == REQ_SHORTCUT) {
            handleShortcutResult(data)
            return
        }
        if (requestCode == REQ_ICON) {
            handleIconResult(data)
            return
        }
        val uri = data.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        prefs.edit()
            .putString(kType(editSlot), if (requestCode == REQ_VIDEO) "video" else "image")
            .putString(kValue(editSlot), uri.toString())
            .apply()
        applyBackground(editSlot)
    }

    // ───────────────────────── interfaz ─────────────────────────

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // Colores que siguen el tema claro/oscuro del sistema (mismos colores base en ambos)
    private fun dark(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun cText(): Int = if (dark()) Color.WHITE else 0xFF1B1B1B.toInt()
    private fun cSub(): Int = if (dark()) 0x99FFFFFF.toInt() else 0x99000000.toInt()
    private fun cAccent(): Int = if (dark()) 0xFF7CC4FF.toInt() else 0xFF0F6CBD.toInt()
    private fun cCard(): Int = if (dark()) 0x14FFFFFF else 0x66FFFFFF
    private fun cStroke(): Int = if (dark()) 0x33FFFFFF else 0x22000000

    /** Animaciones activas: se apagan con "Reducir animaciones" o si el sistema las desactivó. */
    private fun animsOn(): Boolean {
        if (prefs.getBoolean("reduce_anim", false)) return false
        return try {
            Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) != 0f
        } catch (_: Exception) {
            true
        }
    }

    private fun dur(ms: Long): Long = if (animsOn()) ms else 0L

    private fun pressBg(): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(if (dark()) 0x33FFFFFF else 0x22000000))
        addState(intArrayOf(), ColorDrawable(0))
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(prefs.getInt("bg_color", DEFAULT_BG))

        bgLayer = FrameLayout(this)
        root.addView(bgLayer, MATCH, MATCH)

        bgImage = ImageView(this)
        bgImage.scaleType = ImageView.ScaleType.CENTER_CROP
        bgImage.visibility = View.GONE
        bgLayer.addView(bgImage, MATCH, MATCH)

        bgVideo = VideoBackground(this)
        bgVideo.visibility = View.GONE
        bgLayer.addView(bgVideo, MATCH, MATCH)

        // Capa negra muy suave para que los nombres se lean sobre cualquier fondo
        scrim = View(this)
        root.addView(scrim, MATCH, MATCH)
        applyScrim()

        column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL

        desktop = Desktop(this)
        desktop.onSwipe = { delta -> goPage(delta) }
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onLongPress(e: MotionEvent) {
                val x = e.x
                val y = e.y
                val rx = e.rawX
                val ry = e.rawY
                desktop.swipeBlocked = true
                desktop.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showMenu(
                    rx, ry, listOf(
                        MItem("Aplicaciones") { pickToAdd(x, y) },
                        MItem("Widgets") { pickWidget(x, y) },
                        MItem("Accesos directos") { pickShortcut(x, y) },
                        MItem("Enlace personalizado") { addCustomLink(x, y) },
                        MItem("Fondos") { openBackgroundMenu() },
                        MItem("Nueva página") { addPage() },
                        MItem("Ajustes") { openSettings() }
                    )
                )
            }
        })
        desktop.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            true
        }
        column.addView(desktop, LinearLayout.LayoutParams(MATCH, 0, 1f))

        dots = PageDots(this)
        column.addView(dots, LinearLayout.LayoutParams(MATCH, dp(18)))
        updateDots()

        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        root.setOnApplyWindowInsetsListener { _, ins ->
            column.setPadding(
                ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                ins.systemWindowInsetRight, ins.systemWindowInsetBottom
            )
            ins
        }
        setContentView(root)
    }

    private fun updateDots() {
        dots.set(pageCount, currentPage)
        dots.visibility = if (pageCount > 1) View.VISIBLE else View.GONE
    }

    // ───────────────────────── menú emergente ─────────────────────────

    private fun showMenu(rx: Float, ry: Float, items: List<MItem>) {
        popup?.dismiss()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(6), 0, dp(6))
        box.background = GradientDrawable().apply {
            setColor(if (dark()) 0xF2202428.toInt() else 0xF2F6F6F6.toInt())
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), cStroke())
        }
        val pw = PopupWindow(box, WRAP, WRAP, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        for (item in items) {
            val tv = TextView(this)
            tv.text = item.label
            tv.setTextColor(cText())
            tv.textSize = 15f
            tv.setPadding(dp(20), dp(12), dp(32), dp(12))
            tv.background = pressBg()
            tv.setOnClickListener {
                pw.dismiss()
                item.action()
            }
            box.addView(tv)
        }
        box.measure(0, 0)
        val dm = resources.displayMetrics
        val x = rx.toInt().coerceIn(0, (dm.widthPixels - box.measuredWidth).coerceAtLeast(0))
        val y = ry.toInt().coerceIn(0, (dm.heightPixels - box.measuredHeight).coerceAtLeast(0))
        pw.showAtLocation(root, Gravity.TOP or Gravity.START, x, y)
        popup = pw
        if (animsOn()) {
            box.alpha = 0f
            box.scaleX = 0.96f
            box.scaleY = 0.96f
            box.pivotX = 0f
            box.pivotY = 0f
            box.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(ease).start()
        }
    }

    // ───────────────────────── páginas ─────────────────────────

    private fun goPage(delta: Int) {
        val np = currentPage + delta
        if (np < 0 || np >= pageCount) return
        val w = desktop.width.toFloat()
        desktop.animate().translationX(-delta * w).alpha(0f).setDuration(dur(ANIM_MS)).setInterpolator(ease).withEndAction {
            currentPage = np
            save()
            refreshDesktop()
            updateDots()
            desktop.translationX = delta * w
            desktop.animate().translationX(0f).alpha(1f).setDuration(dur(ANIM_MS)).setInterpolator(ease).start()
        }.start()
    }

    private fun addPage() {
        pageCount++
        currentPage = pageCount - 1
        save()
        refreshDesktop()
        updateDots()
        toast("Página $pageCount creada")
    }

    private fun removePage() {
        if (pageCount <= 1) return
        val iter = pins.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            if (p.page == currentPage) {
                deleteIconFiles(p)
                iter.remove()
            } else if (p.page > currentPage) {
                p.page--
            }
        }
        pageCount--
        if (currentPage >= pageCount) currentPage = pageCount - 1
        save()
        refreshDesktop()
        updateDots()
    }

    private fun movePage(pin: Pin, delta: Int) {
        pin.page = (pin.page + delta).coerceIn(0, pageCount - 1)
        save()
        refreshDesktop()
    }

    // ───────────────────────── iconos en el escritorio ─────────────────────────

    private fun loadPins() {
        pins.clear()
        pageCount = prefs.getInt("pages", 1).coerceAtLeast(1)
        currentPage = prefs.getInt("page", 0).coerceIn(0, pageCount - 1)
        try {
            val arr = JSONArray(prefs.getString("apps", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val p = Pin(o.optInt("k", 0), o.getString("p"), o.optString("c", ""))
                p.fx = o.getDouble("x").toFloat()
                p.fy = o.getDouble("y").toFloat()
                p.page = o.optInt("g", 0).coerceIn(0, pageCount - 1)
                p.label = if (o.has("l")) o.getString("l") else null
                p.data = if (o.has("d")) o.getString("d") else null
                p.base = if (o.has("b")) o.getString("b") else null
                p.custom = if (o.has("i")) o.getString("i") else null
                p.widgetId = o.optInt("w", -1)
                p.ww = o.optInt("ww", 40).coerceIn(5, 100)
                p.wh = o.optInt("wh", 30).coerceIn(5, 100)
                pins.add(p)
            }
        } catch (_: Exception) {
        }
    }

    private fun save() {
        val arr = JSONArray()
        for (p in pins) {
            val o = JSONObject()
                .put("k", p.kind).put("p", p.pkg).put("c", p.cls)
                .put("x", p.fx.toDouble()).put("y", p.fy.toDouble()).put("g", p.page)
            p.label?.let { o.put("l", it) }
            p.data?.let { o.put("d", it) }
            p.base?.let { o.put("b", it) }
            p.custom?.let { o.put("i", it) }
            if (p.kind == 3) o.put("w", p.widgetId).put("ww", p.ww).put("wh", p.wh)
            arr.put(o)
        }
        prefs.edit()
            .putString("apps", arr.toString())
            .putInt("pages", pageCount)
            .putInt("page", currentPage)
            .apply()
    }

    /** Accesos directos fijados por otras apps (p. ej. "Agregar a pantalla de inicio") que llegaron mientras no estábamos abiertos. */
    private fun consumePending() {
        val s = prefs.getString("pending", null) ?: return
        prefs.edit().remove("pending").apply()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val p = Pin(2, o.getString("pkg"), o.getString("id"))
                p.label = o.optString("label", "")
                val ic = o.optString("icon", "")
                p.base = if (ic.isEmpty()) null else ic
                p.page = currentPage
                p.fx = (0.08f + 0.1f * (pins.size % 8)).coerceAtMost(1f)
                p.fy = (0.1f + 0.1f * (pins.size % 6)).coerceAtMost(1f)
                pins.add(p)
            }
            save()
        } catch (_: Exception) {
        }
    }

    private fun labelOf(pin: Pin): CharSequence? {
        if (pin.kind == 3) {
            return try {
                awm.getAppWidgetInfo(pin.widgetId)?.loadLabel(pm)
            } catch (_: Exception) {
                null
            }
        }
        if (pin.kind != 0) return pin.label ?: ""
        return try {
            val original = pm.getActivityInfo(ComponentName(pin.pkg, pin.cls), 0).loadLabel(pm)
            pin.label ?: original
        } catch (_: Exception) {
            null
        }
    }

    /** Estilo Windows: del icono adaptable solo se usa la capa frontal (sin placa ni máscara), así queda transparente. */
    private fun styled(d: Drawable): Drawable {
        if (prefs.getBoolean("win_icons", true) && d is AdaptiveIconDrawable) {
            val fg = d.foreground
            if (fg != null) return InsetDrawable(fg, -0.25f)
        }
        return d
    }

    private fun iconFor(pin: Pin): Drawable {
        for (f in listOf(pin.custom, pin.base)) {
            if (f != null) {
                val b = BitmapFactory.decodeFile(File(filesDir, f).path)
                if (b != null) return BitmapDrawable(resources, b)
            }
        }
        if (pin.kind == 0) {
            try {
                return styled(pm.getActivityInfo(ComponentName(pin.pkg, pin.cls), 0).loadIcon(pm))
            } catch (_: Exception) {
            }
        }
        return pm.defaultActivityIcon
    }

    private fun refreshDesktop() {
        desktop.removeAllViews()
        var changed = false
        val iter = pins.iterator()
        while (iter.hasNext()) {
            val pin = iter.next()
            if (labelOf(pin) == null) { // la app o el widget ya no existe
                deleteIconFiles(pin)
                iter.remove()
                changed = true
            }
        }
        if (changed) save()
        for (pin in pins) {
            if (pin.page != currentPage) continue
            val v = iconView(pin) ?: continue
            desktop.addView(v, FrameLayout.LayoutParams(WRAP, WRAP))
        }
    }

    private fun iconView(pin: Pin): View? {
        val text = labelOf(pin) ?: return null
        if (pin.kind == 3) return widgetView(pin)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(8), dp(10), dp(8))

        val iconBox = FrameLayout(this)
        val icon = ImageView(this)
        icon.setImageDrawable(iconFor(pin))
        iconBox.addView(icon, FrameLayout.LayoutParams(dp(44), dp(44)))
        if (prefs.getBoolean("badge_on", true)) {
            val badge = ImageView(this)
            badge.setImageBitmap(badgeBitmap())
            badge.scaleType = ImageView.ScaleType.FIT_CENTER
            iconBox.addView(badge, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.BOTTOM or Gravity.END))
        }
        row.addView(iconBox, LinearLayout.LayoutParams(dp(44), dp(44)))

        val label = TextView(this)
        label.text = text
        label.setTextColor(Color.WHITE)
        label.textSize = 13f
        label.setTypeface(label.typeface, Typeface.BOLD)
        label.setSingleLine()
        label.ellipsize = TextUtils.TruncateAt.END
        label.maxWidth = dp(130)
        label.setShadowLayer(4f, 0f, 1f, Color.BLACK)
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.leftMargin = dp(8)
        row.addView(label, lp)

        row.tag = pin
        row.setOnTouchListener(IconTouch(pin, row))
        return row
    }

    private fun addPin(pin: Pin, x: Float, y: Float) {
        pin.page = currentPage
        val v = iconView(pin) ?: return
        val w: Int
        val h: Int
        if (pin.kind == 3) {
            w = desktop.width * pin.ww / 100
            h = desktop.height * pin.wh / 100
        } else {
            v.measure(0, 0)
            w = v.measuredWidth
            h = v.measuredHeight
        }
        pin.fx = ((x - w / 2f) / (desktop.width - w).coerceAtLeast(1)).coerceIn(0f, 1f)
        pin.fy = ((y - h / 2f) / (desktop.height - h).coerceAtLeast(1)).coerceIn(0f, 1f)
        pins.add(pin)
        desktop.addView(v, FrameLayout.LayoutParams(WRAP, WRAP))
        save()
    }

    private fun deleteIconFiles(pin: Pin) {
        pin.base?.let { File(filesDir, it).delete() }
        pin.custom?.let { File(filesDir, it).delete() }
        if (pin.kind == 3) {
            try {
                host.deleteAppWidgetId(pin.widgetId)
            } catch (_: Exception) {
            }
        }
    }

    private fun removePin(pin: Pin, v: View) {
        pins.remove(pin)
        deleteIconFiles(pin)
        desktop.removeView(v)
        save()
    }

    private fun dragTo(pin: Pin, v: View, left: Float, top: Float) {
        val loc = IntArray(2)
        desktop.getLocationOnScreen(loc)
        pin.fx = ((left - loc[0]) / (desktop.width - v.width).coerceAtLeast(1)).coerceIn(0f, 1f)
        pin.fy = ((top - loc[1]) / (desktop.height - v.height).coerceAtLeast(1)).coerceIn(0f, 1f)
        desktop.requestLayout()
    }

    /** Toque = abrir. Mantener y arrastrar = mover. Mantener y soltar sin mover = menú del icono. */
    private inner class IconTouch(val pin: Pin, val v: View) : View.OnTouchListener {
        private var dragging = false
        private var cancelled = false
        private var moved = false
        private var downX = 0f
        private var downY = 0f
        private var offX = 0f
        private var offY = 0f
        private var prevL = 0f
        private var prevT = 0f
        private var air: AirDrag? = null
        private val slop = ViewConfiguration.get(this@MainActivity).scaledTouchSlop

        private val longPress = Runnable {
            dragging = true
            desktop.swipeBlocked = true
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            v.parent?.requestDisallowInterceptTouchEvent(true)
            v.alpha = 0.8f
            if (animsOn() && prefs.getBoolean("phys", true)) {
                v.background = null // sin el recuadro de resaltado, para que solo se incline el icono
                val a = AirDrag(v, resources.displayMetrics.density)
                air = a
                a.grab()
                val loc = IntArray(2)
                desktop.getLocationOnScreen(loc)
                prevL = (loc[0] + v.left).toFloat()
                prevT = (loc[1] + v.top).toFloat()
            }
        }

        override fun onTouch(view: View, ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    cancelled = false
                    moved = false
                    downX = ev.rawX
                    downY = ev.rawY
                    offX = ev.x
                    offY = ev.y
                    v.setBackgroundColor(0x33FFFFFF)
                    v.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                }
                MotionEvent.ACTION_MOVE -> {
                    val far = abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop
                    if (dragging) {
                        if (far) moved = true
                        val a = air
                        if (a != null) {
                            val loc = IntArray(2)
                            desktop.getLocationOnScreen(loc)
                            val maxL = (loc[0] + desktop.width - v.width).toFloat().coerceAtLeast(loc[0].toFloat())
                            val maxT = (loc[1] + desktop.height - v.height).toFloat().coerceAtLeast(loc[1].toFloat())
                            val nl = (ev.rawX - offX).coerceIn(loc[0].toFloat(), maxL)
                            val nt = (ev.rawY - offY).coerceIn(loc[1].toFloat(), maxT)
                            a.moved(nl - prevL, nt - prevT)
                            prevL = nl
                            prevT = nt
                        }
                        dragTo(pin, v, ev.rawX - offX, ev.rawY - offY)
                    } else if (far) {
                        cancelled = true
                        v.removeCallbacks(longPress)
                        v.background = null
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.removeCallbacks(longPress)
                    v.background = null
                    v.alpha = 1f
                    air?.release()
                    air = null
                    if (dragging) {
                        if (moved) {
                            save()
                            if (prefs.getBoolean("haptic_drop", true)) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        } else {
                            showMenu(ev.rawX, ev.rawY, iconMenu(pin, v))
                        }
                    } else if (!cancelled) {
                        open(pin)
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(longPress)
                    v.background = null
                    v.alpha = 1f
                    air?.release()
                    air = null
                }
            }
            return true
        }
    }

    private fun iconMenu(pin: Pin, v: View): List<MItem> {
        val items = ArrayList<MItem>()
        items.add(MItem("Cambiar icono") {
            iconPin = pin
            pickFile("image/*", REQ_ICON)
        })
        items.add(MItem("Cambiar nombre") { renameDialog(pin) })
        if (pin.custom != null) {
            items.add(MItem("Icono original") {
                pin.custom?.let { File(filesDir, it).delete() }
                pin.custom = null
                save()
                refreshDesktop()
            })
        }
        if (pageCount > 1) {
            if (pin.page < pageCount - 1) items.add(MItem("Mover a la página siguiente") { movePage(pin, 1) })
            if (pin.page > 0) items.add(MItem("Mover a la página anterior") { movePage(pin, -1) })
        }
        if (pin.pkg.isNotEmpty()) {
            val g = isGame(pin.pkg)
            items.add(MItem(if (g) "Quitar marca de juego" else "Marcar como juego") { setGame(pin.pkg, !g) })
            val wn = wantsWindow(pin.pkg, g)
            items.add(MItem(if (wn) "Abrir a pantalla completa" else "Abrir en ventana") { setWindow(pin.pkg, !wn) })
            val fp = shouldShowFps(pin.pkg)
            items.add(MItem(if (fp) "Ocultar contador de FPS" else "Mostrar contador de FPS") { setFps(pin.pkg, !fp) })
        }
        items.add(MItem("Quitar") { removePin(pin, v) })
        return items
    }

    // ───────────────────────── juegos ─────────────────────────

    private fun isGame(pkg: String): Boolean {
        if (pkg.isEmpty()) return false
        if (prefs.getStringSet("g_yes", null)?.contains(pkg) == true) return true
        if (prefs.getStringSet("g_no", null)?.contains(pkg) == true) return false
        return try {
            val ai = pm.getApplicationInfo(pkg, 0)
            ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        } catch (_: Exception) {
            false
        }
    }

    private fun setGame(pkg: String, game: Boolean) {
        val yes = HashSet<String>(prefs.getStringSet("g_yes", null) ?: emptySet<String>())
        val no = HashSet<String>(prefs.getStringSet("g_no", null) ?: emptySet<String>())
        if (game) {
            yes.add(pkg)
            no.remove(pkg)
        } else {
            yes.remove(pkg)
            no.add(pkg)
        }
        prefs.edit().putStringSet("g_yes", yes).putStringSet("g_no", no).apply()
        toast(if (game) "Marcado como juego" else "Ya no se trata como juego")
    }

    /** Deja el fondo animado quieto (video = último cuadro; GIF = cuadro actual) para no gastar recursos mientras juegas. */
    private fun freezeBackground() {
        if (frozen || !prefs.getBoolean("freeze_bg", true)) return
        val type = prefs.getString(kType(curSlot), "color")
        if (type == "video") {
            val bmp = try {
                bgVideo.bitmap
            } catch (_: Exception) {
                null
            }
            if (bmp != null) {
                bgImage.setImageBitmap(bmp)
                bgImage.visibility = View.VISIBLE
            }
            bgVideo.visibility = View.INVISIBLE
            bgVideo.stopPlayback()
            frozen = true
        } else if (type == "image") {
            val d = bgImage.drawable
            if (d is AnimatedImageDrawable) {
                d.stop()
                frozen = true
            }
        }
        sawBlur = false
    }

    private fun unfreezeBackground() {
        if (!frozen) return
        frozen = false
        val type = prefs.getString(kType(curSlot), "color")
        if (type == "video") {
            bgVideo.visibility = View.VISIBLE
            bgVideo.startPlayback()
            bgImage.postDelayed({
                if (!frozen && prefs.getString(kType(curSlot), "color") == "video") {
                    bgImage.setImageDrawable(null)
                    bgImage.visibility = View.GONE
                }
            }, 500)
        } else if (type == "image") {
            (bgImage.drawable as? AnimatedImageDrawable)?.start()
        }
    }

    // ───────────────────────── abrir (en ventana) ─────────────────────────

    private fun setPkgFlag(yesKey: String, noKey: String, pkg: String, on: Boolean) {
        val yes = HashSet<String>(prefs.getStringSet(yesKey, null) ?: emptySet<String>())
        val no = HashSet<String>(prefs.getStringSet(noKey, null) ?: emptySet<String>())
        if (on) {
            yes.add(pkg)
            no.remove(pkg)
        } else {
            yes.remove(pkg)
            no.add(pkg)
        }
        prefs.edit().putStringSet(yesKey, yes).putStringSet(noKey, no).apply()
    }

    /** ¿Esta app se abre en ventana? La decisión por app manda; si no hay, valen los ajustes generales. */
    private fun wantsWindow(pkg: String, game: Boolean): Boolean {
        if (pkg.isNotEmpty()) {
            if (prefs.getStringSet("win_no", null)?.contains(pkg) == true) return false
            if (prefs.getStringSet("win_yes", null)?.contains(pkg) == true) return true
        }
        return if (game) prefs.getBoolean("game_window", true) else prefs.getBoolean("windowed", true)
    }

    private fun setWindow(pkg: String, on: Boolean) {
        setPkgFlag("win_yes", "win_no", pkg, on)
        toast(if (on) "Se abrirá en ventana" else "Se abrirá a pantalla completa")
    }

    @Suppress("DEPRECATION")
    private fun realLandscape(): Boolean {
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels > dm.heightPixels
    }

    /** Ancho y alto de pantalla en la orientación ACTUAL (aunque el launcher aún no haya actualizado sus métricas). */
    private fun screenSize(): Pair<Int, Int> {
        val dm = resources.displayMetrics
        var w = dm.widthPixels
        var h = dm.heightPixels
        if ((w > h) != realLandscape()) {
            val t = w
            w = h
            h = t
        }
        return Pair(w, h)
    }

    private fun windowOptions(pkg: String, game: Boolean, stagger: Boolean = true): Bundle? {
        if (!wantsWindow(pkg, game)) {
            lastRect = null
            return null
        }
        return try {
            val sz = screenSize()
            val sw = sz.first
            val sh = sz.second
            val r: Rect = if (game) {
                val w = sw * prefs.getInt("gw_w", 98) / 100
                val h = sh * prefs.getInt("gw_h", 95) / 100
                val l = ((sw - w) * prefs.getInt("gw_x", 50) / 100).coerceAtLeast(0)
                val t = ((sh - h) * prefs.getInt("gw_y", 50) / 100).coerceAtLeast(0)
                Rect(l, t, l + w, t + h)
            } else {
                val w = sw * prefs.getInt("aw_w", 62) / 100
                val h = sh * prefs.getInt("aw_h", 72) / 100
                val step = dp(36)
                val n = if (stagger) winCount++ % 6 else 3
                val bx = (sw - w) * prefs.getInt("aw_x", 50) / 100
                val by = (sh - h) * prefs.getInt("aw_y", 50) / 100
                val l = (bx + (n - 3) * step).coerceIn(0, (sw - w).coerceAtLeast(0))
                val t = (by + (n - 3) * step).coerceIn(0, (sh - h).coerceAtLeast(0))
                Rect(l, t, l + w, t + h)
            }
            lastRect = r
            val o = ActivityOptions.makeBasic()
            o.setLaunchBounds(r)
            try {
                // Modo "ventana libre" (5). Solo funciona si el sistema tiene ventanas libres activadas.
                ActivityOptions::class.java
                    .getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                    .invoke(o, 5)
            } catch (_: Throwable) {
            }
            o.toBundle()
        } catch (_: Exception) {
            null
        }
    }

    // ───────────── al girar la tablet: volver a dar su tamaño a la ventana abierta ─────────────

    private fun hasUsageAccess(): Boolean {
        return try {
            val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    /** ¿Sigue esa app abierta y visible? Según su último evento de actividad. null = no se puede saber (falta el permiso). */
    private fun usageAlive(pkg: String): Boolean? {
        if (!hasUsageAccess()) return null
        return try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val ev = usm.queryEvents(now - 6 * 3600 * 1000L, now)
            val e = UsageEvents.Event()
            var alive = false
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.packageName != pkg) continue
                when (e.eventType) {
                    UsageEvents.Event.ACTIVITY_RESUMED, UsageEvents.Event.ACTIVITY_PAUSED -> alive = true
                    UsageEvents.Event.ACTIVITY_STOPPED -> alive = false
                }
            }
            alive
        } catch (_: Exception) {
            null
        }
    }

    /** Junta varios avisos de giro seguidos en uno solo (el sistema manda 2 o 3 por cada giro). */
    private fun scheduleRotateFix() {
        if (rotPending) return
        rotPending = true
        rotHandler.postDelayed(rotRun, 600)
    }

    /** 0 = no reacomodar, 1 = seguro (solo si puede confirmar que el juego sigue abierto), 2 = siempre. */
    private fun rotateMode(): Int =
        if (!prefs.getBoolean("rotate_fix", true)) 0 else prefs.getInt("rotate_mode", 1).coerceIn(1, 2)

    private fun pause(ms: Long): Boolean {
        return try {
            Thread.sleep(ms)
            true
        } catch (_: InterruptedException) {
            false
        }
    }

    /** ¿La ventana ya tiene (más o menos) el tamaño que pedimos? Deja margen por la barra de título. */
    private fun sameSize(a: Rect, b: Rect): Boolean {
        val tw = (b.width() * 0.15f).toInt().coerceAtLeast(dp(60))
        val th = (b.height() * 0.15f).toInt().coerceAtLeast(dp(60))
        return abs(a.width() - b.width()) <= tw && abs(a.height() - b.height()) <= th
    }

    private fun onRotated() {
        val land = realLandscape()
        if (land == lastLand) return
        lastLand = land
        val mode = rotateMode()
        if (mode == 0) return
        val l = lastLaunch ?: return
        if (!wantsWindow(l.pkg, l.game)) return
        val opts = windowOptions(l.pkg, l.game, false) // recalcula el tamaño con la orientación NUEVA
        val r = lastRect ?: return
        val gen = ++rotGen
        val head = "Giro a " + (if (land) "horizontal" else "vertical") + " · " + l.pkg +
                "\nTamaño pedido: " + r.toShortString()
        rotLog = head
        Thread { fixWindowAfterRotation(l, opts, r, mode, gen, head) }.start()
    }

    /**
     * Intenta dejar la ventana del juego con el tamaño de la orientación nueva, por todos los caminos que hay:
     *  1) Con Shizuku: pedirle el tamaño directo a la tarea (sin reabrir nada) y comprobar que lo tomó.
     *  2) Reabrirlo con los límites nuevos (no necesita permisos). En modo seguro solo si se confirma que sigue abierto.
     *  3) Con Shizuku: comprobar y reintentar el tamaño después de reabrirlo.
     * Todo se reintenta unos segundos, porque el juego tarda en reaparecer después de girar.
     */
    private fun fixWindowAfterRotation(l: Launch, opts: Bundle?, r: Rect, mode: Int, gen: Int, head: String) {
        val log = StringBuilder(head).append('\n')
        fun gone(): Boolean = gen != rotGen || isFinishing || isDestroyed
        fun save() {
            if (gen == rotGen) rotLog = log.toString()
        }
        val shell = FpsMonitor.shizukuRunning() && FpsMonitor.shizukuGranted()
        log.append("Shizuku: ").append(if (shell) "listo" else "no disponible").append('\n')
        var done = false
        var applied = false

        // Paso 1: con Shizuku, cambiar el tamaño directamente (es seguro aunque el juego ya se haya cerrado)
        if (shell) {
            log.append("— Cambiar el tamaño directo —\n")
            done = resizeUntilFits(l.pkg, r, log, 5) { gone() }
            if (done) applied = true
        }

        // Paso 2: reabrirlo con los límites nuevos
        if (!done) {
            if (gone()) return
            var alive: Boolean? = null
            if (mode == 2) {
                alive = true
                log.append("— Modo «siempre»: se reabre sin comprobar si sigue abierto —\n")
            } else {
                log.append("— Comprobando si el juego sigue abierto —\n")
                for (n in 1..4) {
                    if (gone()) return
                    var a: Boolean? = if (shell) FpsMonitor.listLayers(l.pkg)?.isNotEmpty() else null
                    if (a != true) {
                        val u = usageAlive(l.pkg)
                        if (u != null) a = u
                    }
                    alive = a
                    if (a != false) break // true = sigue abierto, null = no se puede saber
                    if (!pause(1000)) return // false: puede estar reabriéndose tras el giro, reintentar
                }
            }
            if (alive != true) {
                if (alive == null) {
                    log.append("No puedo saber si el juego sigue abierto, así que no lo reabro.\n")
                    log.append("Solución: activa Shizuku o el Acceso de uso, o pon el reacomodo en «siempre».\n")
                } else {
                    log.append("El juego ya no está abierto: no hay nada que reacomodar.\n")
                }
            } else {
                log.append("Reabriendo con el tamaño nuevo…\n")
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    try {
                        l.go(opts)
                    } catch (_: Exception) {
                    }
                }
                applied = true
                FpsMonitor.updateBounds(r)
                if (shell) {
                    if (!pause(900)) return
                    log.append("— Comprobando el tamaño tras reabrir —\n")
                    done = resizeUntilFits(l.pkg, r, log, 4) { gone() }
                } else {
                    log.append("(Sin Shizuku no puedo comprobar el resultado.)\n")
                }
            }
        }

        log.append(if (done) "Resultado: listo.\n" else if (applied) "Resultado: pedido enviado.\n" else "Resultado: no se pudo reacomodar.\n")
        save()
        if (!applied && !gone()) {
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    toast("No pude reacomodar la ventana. Mira Ajustes → Contador de FPS → Probar el contador")
                }
            }
        }
    }

    /** Pide el tamaño con Shizuku y comprueba que la ventana lo tomó; reintenta unas veces. true = ya quedó bien. */
    private fun resizeUntilFits(pkg: String, r: Rect, log: StringBuilder, tries: Int, cancelled: () -> Boolean): Boolean {
        for (n in 1..tries) {
            if (cancelled()) return false
            // a partir del 3.er intento también se marca la tarea como redimensionable (por si el juego dice que no lo es)
            val out = FpsMonitor.resizeTask(pkg, r, n >= 3)
            log.append("Intento ").append(n).append(": ")
                .append(if (out == null) "no encontré la tarea del juego" else if (out.isBlank()) "orden enviada" else out.trim().take(120))
                .append('\n')
            if (!pause(800)) return false
            val cur = FpsMonitor.windowBounds(pkg)
            if (cur != null && sameSize(cur, r)) {
                log.append("Ventana ahora: ").append(cur.toShortString()).append(" ✓\n")
                FpsMonitor.updateBounds(r)
                return true
            }
            log.append("Ventana ahora: ").append(cur?.toShortString() ?: "no detectada").append('\n')
            if (out == null && n >= 2) return false // sin tarea no hay nada que cambiar
            if (!pause(500)) return false
        }
        return false
    }

    private fun shouldShowFps(pkg: String): Boolean {
        if (pkg.isEmpty()) return false
        if (prefs.getStringSet("fps_no", null)?.contains(pkg) == true) return false
        if (prefs.getStringSet("fps_yes", null)?.contains(pkg) == true) return true
        return prefs.getBoolean("fps_games", true) && isGame(pkg)
    }

    private fun setFps(pkg: String, on: Boolean) {
        setPkgFlag("fps_yes", "fps_no", pkg, on)
        toast(if (on) "FPS activado para esta app" else "FPS desactivado para esta app")
        if (on && !FpsMonitor.ready(this)) openFpsSettings()
    }

    private fun afterLaunch(pkg: String) {
        if (!shouldShowFps(pkg)) return
        if (!FpsMonitor.ready(this)) {
            if (!fpsHinted) {
                fpsHinted = true
                toast("FPS: falta activar Shizuku o la superposición (Ajustes → Contador de FPS)")
            }
            return
        }
        FpsMonitor.start(
            applicationContext, pkg, prefs.getInt("fps_pos", 0),
            prefs.getInt("fps_items", FpsMonitor.DEFAULT_ITEMS), lastRect
        )
    }

    private fun startIntent(i: Intent, pkg: String) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val game = isGame(pkg)
        try {
            startActivity(i, windowOptions(pkg, game))
            if (pkg.isNotEmpty()) lastPkg = pkg
            lastLaunch = if (lastRect != null && pkg.isNotEmpty()) Launch(pkg, game) { o -> startActivity(i, o) } else null
            if (game) freezeBackground()
            afterLaunch(pkg)
        } catch (_: Exception) {
            toast("No se pudo abrir")
        }
    }

    private fun open(pin: Pin) {
        when (pin.kind) {
            0 -> startIntent(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(pin.pkg, pin.cls)),
                pin.pkg
            )
            1 -> {
                val i = try {
                    Intent.parseUri(pin.data ?: "", 0)
                } catch (_: Exception) {
                    null
                }
                if (i == null) toast("Acceso directo inválido") else startIntent(i, pin.pkg)
            }
            else -> {
                val game = isGame(pin.pkg)
                try {
                    val la = getSystemService(LauncherApps::class.java)
                    la.startShortcut(pin.pkg, pin.cls, null, windowOptions(pin.pkg, game), Process.myUserHandle())
                    if (pin.pkg.isNotEmpty()) lastPkg = pin.pkg
                    lastLaunch = if (lastRect != null && pin.pkg.isNotEmpty()) {
                        Launch(pin.pkg, game) { o -> la.startShortcut(pin.pkg, pin.cls, null, o, Process.myUserHandle()) }
                    } else null
                    if (game) freezeBackground()
                    afterLaunch(pin.pkg)
                } catch (_: Exception) {
                    toast("No se pudo abrir (el launcher debe ser el predeterminado)")
                }
            }
        }
    }

    // ───────────────────────── lista de apps / accesos directos ─────────────────────────

    private fun loadApps(query: Intent, cb: (List<AppItem>) -> Unit) {
        Thread {
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    AppItem(ri.loadLabel(pm).toString(), ri.activityInfo.packageName, ri.activityInfo.name, ri.loadIcon(pm))
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread { cb(list) }
        }.start()
    }

    private fun pickToAdd(x: Float, y: Float) {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        loadApps(q) { apps ->
            showAppList(apps) { app -> addPin(Pin(0, app.pkg, app.cls), x, y) }
        }
    }

    private fun pickShortcut(x: Float, y: Float) {
        pendX = x
        pendY = y
        loadApps(Intent(Intent.ACTION_CREATE_SHORTCUT)) { apps ->
            if (apps.isEmpty()) {
                toast("Ninguna app ofrece accesos directos")
            } else {
                showAppList(apps) { a ->
                    try {
                        skipRandom = true
                        startActivityForResult(
                            Intent(Intent.ACTION_CREATE_SHORTCUT).setComponent(ComponentName(a.pkg, a.cls)),
                            REQ_SHORTCUT
                        )
                    } catch (_: Exception) {
                        toast("No se pudo abrir")
                    }
                }
            }
        }
    }

    private fun saveBitmap(src: Bitmap): String? {
        return try {
            val m = maxOf(src.width, src.height)
            val bmp = if (m > 192) {
                val s = 192f / m
                Bitmap.createScaledBitmap(src, maxOf(1, (src.width * s).toInt()), maxOf(1, (src.height * s).toInt()), true)
            } else src
            val name = "ic_" + System.nanoTime() + ".png"
            FileOutputStream(File(filesDir, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            name
        } catch (_: Exception) {
            null
        }
    }

    private fun handleShortcutResult(data: Intent) {
        val si = data.getParcelableExtra<Intent>(Intent.EXTRA_SHORTCUT_INTENT)
        if (si == null) {
            toast("No se pudo crear ese acceso directo")
            return
        }
        val name = data.getStringExtra(Intent.EXTRA_SHORTCUT_NAME) ?: "Acceso directo"
        var bmp = data.getParcelableExtra<Bitmap>(Intent.EXTRA_SHORTCUT_ICON)
        if (bmp == null) {
            val res = data.getParcelableExtra<Intent.ShortcutIconResource>(Intent.EXTRA_SHORTCUT_ICON_RESOURCE)
            if (res != null) {
                try {
                    val r = pm.getResourcesForApplication(res.packageName)
                    val id = r.getIdentifier(res.resourceName, null, null)
                    bmp = drawableToBitmap(r.getDrawable(id, null), 192)
                } catch (_: Exception) {
                }
            }
        }
        val pin = Pin(1, si.component?.packageName ?: "", "")
        pin.label = name
        pin.data = si.toUri(0)
        if (bmp != null) pin.base = saveBitmap(bmp)
        addPin(pin, pendX, pendY)
    }

    private fun importIcon(uri: Uri): String? {
        return try {
            val src = ImageDecoder.createSource(contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val m = maxOf(info.size.width, info.size.height)
                if (m > 192) {
                    val s = 192f / m
                    dec.setTargetSize(maxOf(1, (info.size.width * s).toInt()), maxOf(1, (info.size.height * s).toInt()))
                }
            }
            saveBitmap(bmp)
        } catch (_: Exception) {
            null
        }
    }

    private fun handleIconResult(data: Intent) {
        val uri = data.data ?: return
        val pin = iconPin ?: return
        val name = importIcon(uri)
        if (name == null) {
            toast("No se pudo usar esa imagen")
            return
        }
        pin.custom?.let { File(filesDir, it).delete() }
        pin.custom = name
        save()
        refreshDesktop()
    }

    private fun showAppList(apps: List<AppItem>, onPick: (AppItem) -> Unit) {
        if (isFinishing || isDestroyed) return
        dialog?.dismiss()
        var shown: List<AppItem> = apps

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(12), dp(12), dp(8))

        val search = EditText(this)
        search.hint = "Buscar"
        search.setSingleLine()
        search.setTextColor(cText())
        search.setHintTextColor(cSub())

        val list = ListView(this)
        list.divider = null

        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(position: Int): Any = shown[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val row: LinearLayout = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                    addView(ImageView(context), LinearLayout.LayoutParams(dp(36), dp(36)))
                    val tv = TextView(context)
                    tv.setTextColor(cText())
                    tv.textSize = 16f
                    tv.setSingleLine()
                    tv.ellipsize = TextUtils.TruncateAt.END
                    val lp = LinearLayout.LayoutParams(WRAP, WRAP)
                    lp.leftMargin = dp(14)
                    addView(tv, lp)
                }
                val a = shown[position]
                (row.getChildAt(0) as ImageView).setImageDrawable(a.icon)
                (row.getChildAt(1) as TextView).text = a.label
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val a = shown[pos]
            dialog?.dismiss()
            onPick(a)
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString().trim().lowercase()
                shown = if (q.isEmpty()) apps else apps.filter { it.label.lowercase().contains(q) }
                adapter.notifyDataSetChanged()
            }
        })

        box.addView(search, LinearLayout.LayoutParams(MATCH, WRAP))
        val dm = resources.displayMetrics
        box.addView(list, LinearLayout.LayoutParams(MATCH, (dm.heightPixels * 0.6f).toInt()))

        val d = AlertDialog.Builder(this).setView(box).create()
        glass(d)
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        d.show()
        d.window?.setLayout(minOf((dm.widthPixels * 0.92f).toInt(), dp(520)), WRAP)
        dialog = d
    }

    // ───────────────────────── widgets ─────────────────────────

    private fun pickWidget(x: Float, y: Float) {
        pendX = x
        pendY = y
        Thread {
            val infos = HashMap<String, AppWidgetProviderInfo>()
            val list = ArrayList<AppItem>()
            val dpi = resources.displayMetrics.densityDpi
            for (info in awm.installedProviders) {
                val pkg = info.provider.packageName
                val cls = info.provider.className
                val appLabel = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                } catch (_: Exception) {
                    pkg
                }
                val wl = try {
                    info.loadLabel(pm)
                } catch (_: Exception) {
                    cls
                }
                val ic: Drawable = (try {
                    info.loadIcon(this, dpi)
                } catch (_: Exception) {
                    null
                }) ?: pm.defaultActivityIcon
                infos[info.provider.flattenToString()] = info
                list.add(AppItem(appLabel + " · " + wl, pkg, cls, ic))
            }
            list.sortBy { it.label.lowercase() }
            runOnUiThread {
                if (list.isEmpty()) {
                    toast("No se encontraron widgets")
                } else {
                    showAppList(list) { a ->
                        val info = infos[ComponentName(a.pkg, a.cls).flattenToString()]
                        if (info != null) startWidgetBind(info)
                    }
                }
            }
        }.start()
    }

    private fun startWidgetBind(info: AppWidgetProviderInfo) {
        try {
            val id = host.allocateAppWidgetId()
            wId = id
            wInfo = info
            if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) {
                configureWidget()
            } else {
                val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
                skipRandom = true
                startActivityForResult(i, REQ_BIND)
            }
        } catch (_: Exception) {
            cancelWidget()
            toast("No se pudo agregar el widget")
        }
    }

    private fun configureWidget() {
        val info = wInfo ?: return
        if (info.configure != null) {
            try {
                skipRandom = true
                host.startAppWidgetConfigureActivityForResult(this, wId, 0, REQ_WCONFIG, null)
            } catch (_: Exception) {
                finishWidget()
            }
        } else {
            finishWidget()
        }
    }

    private fun finishWidget() {
        val info = wInfo ?: return
        val id = wId
        wId = -1
        wInfo = null
        val pin = Pin(3, info.provider.packageName, info.provider.className)
        pin.widgetId = id
        val dm = resources.displayMetrics
        pin.ww = (info.minWidth * 100 / dm.widthPixels).coerceIn(15, 100)
        pin.wh = (info.minHeight * 100 / dm.heightPixels).coerceIn(10, 100)
        addPin(pin, pendX, pendY)
    }

    private fun cancelWidget() {
        if (wId != -1) {
            try {
                host.deleteAppWidgetId(wId)
            } catch (_: Exception) {
            }
        }
        wId = -1
        wInfo = null
    }

    private fun widgetView(pin: Pin): View? {
        val info = awm.getAppWidgetInfo(pin.widgetId) ?: return null
        val hv = host.createView(this, pin.widgetId, info) as? WidgetView ?: return null
        hv.tag = pin
        val wt = WidgetTouch(pin, hv)
        hv.onLongPress = { lx, ly, rx, ry -> wt.start(lx, ly, rx, ry) }
        hv.onDragEvent = { ev -> wt.event(ev) }
        return hv
    }

    /** Mantener presionado un widget = arrastrarlo; soltar sin mover = menú (tamaño / quitar). */
    private inner class WidgetTouch(val pin: Pin, val v: View) {
        private var offX = 0f
        private var offY = 0f
        private var startX = 0f
        private var startY = 0f
        private var moved = false
        private val slop = ViewConfiguration.get(this@MainActivity).scaledTouchSlop

        fun start(lx: Float, ly: Float, rx: Float, ry: Float) {
            offX = lx
            offY = ly
            startX = rx
            startY = ry
            moved = false
            desktop.swipeBlocked = true
            v.alpha = 0.7f
        }

        fun event(ev: MotionEvent) {
            val a = ev.actionMasked
            if (a == MotionEvent.ACTION_MOVE) {
                if (abs(ev.rawX - startX) > slop || abs(ev.rawY - startY) > slop) moved = true
                if (moved) dragTo(pin, v, ev.rawX - offX, ev.rawY - offY)
            } else if (a == MotionEvent.ACTION_UP) {
                v.alpha = 1f
                if (moved) save() else showMenu(ev.rawX, ev.rawY, widgetMenu(pin, v))
            } else if (a == MotionEvent.ACTION_CANCEL) {
                v.alpha = 1f
            }
        }
    }

    private fun widgetMenu(pin: Pin, v: View): List<MItem> {
        val items = ArrayList<MItem>()
        items.add(MItem("Tamaño del widget") { widgetSizeDialog(pin) })
        if (pageCount > 1) {
            if (pin.page < pageCount - 1) items.add(MItem("Mover a la página siguiente") { movePage(pin, 1) })
            if (pin.page > 0) items.add(MItem("Mover a la página anterior") { movePage(pin, -1) })
        }
        items.add(MItem("Quitar") { removePin(pin, v) })
        return items
    }

    private fun addSlider(box: LinearLayout, title: String, min: Int, value: Int, onChange: (Int) -> Unit) {
        val tv = TextView(this)
        tv.setTextColor(cText())
        tv.textSize = 14f
        tv.setPadding(0, dp(8), 0, 0)
        tv.text = title + ": " + value + "%"
        val sb = SeekBar(this)
        sb.max = 100 - min
        sb.progress = (value - min).coerceIn(0, 100 - min)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + min
                tv.text = title + ": " + v + "%"
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
    }

    private fun sectionTitle(box: LinearLayout, text: String) {
        val t = TextView(this)
        t.text = text
        t.setTextColor(cAccent())
        t.textSize = 14f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.setPadding(0, dp(12), 0, 0)
        box.addView(t)
    }

    private fun widgetSizeDialog(pin: Pin) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(8))
        addSlider(box, "Ancho", 10, pin.ww) {
            pin.ww = it
            desktop.requestLayout()
        }
        addSlider(box, "Alto", 10, pin.wh) {
            pin.wh = it
            desktop.requestLayout()
        }
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Tamaño del widget").setView(box)
            .setPositiveButton("Listo", null).create()
        d.setOnDismissListener { save() }
        glass(d)
        d.show()
        dialog = d
    }

    // ───────────────────────── tamaño de ventanas ─────────────────────────

    private fun hintText(box: LinearLayout, text: String) {
        val t = TextView(this)
        t.text = text
        t.setTextColor(cSub())
        t.textSize = 12f
        t.setPadding(0, dp(2), 0, 0)
        box.addView(t)
    }

    private fun openWindowSizes() {
        val dm = resources.displayMetrics
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(4), dp(20), dp(8))

        val preview = WindowPreview(this, dm.widthPixels, dm.heightPixels, animsOn())
        val pl = LinearLayout.LayoutParams(WRAP, WRAP)
        pl.gravity = Gravity.CENTER_HORIZONTAL
        pl.topMargin = dp(8)
        box.addView(preview, pl)

        fun frac(k: String, def: Int): Float = prefs.getInt(k, def) / 100f
        fun refresh() {
            preview.set(
                floatArrayOf(frac("gw_w", 98), frac("gw_h", 95), frac("gw_x", 50), frac("gw_y", 50)),
                floatArrayOf(frac("aw_w", 62), frac("aw_h", 72), frac("aw_x", 50), frac("aw_y", 50))
            )
        }
        fun slider(title: String, key: String, def: Int, min: Int) {
            addSlider(box, title, min, prefs.getInt(key, def)) {
                prefs.edit().putInt(key, it).apply()
                refresh()
            }
        }
        refresh()

        hintText(box, "Posición: 0% = pegada arriba / izquierda, 100% = abajo / derecha")
        sectionTitle(box, "Juegos (verde)")
        slider("Ancho", "gw_w", 98, 30)
        slider("Alto", "gw_h", 95, 30)
        slider("Posición horizontal", "gw_x", 50, 0)
        slider("Posición vertical", "gw_y", 50, 0)
        sectionTitle(box, "Apps normales (naranja)")
        slider("Ancho", "aw_w", 62, 30)
        slider("Alto", "aw_h", 72, 30)
        slider("Posición horizontal", "aw_x", 50, 0)
        slider("Posición vertical", "aw_y", 50, 0)
        hintText(box, "Las apps normales salen un poco escalonadas para no taparse del todo.")

        val sv = ScrollView(this)
        sv.addView(box)
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Tamaño de ventanas").setView(sv)
            .setNeutralButton("Juegos al máximo") { _, _ ->
                prefs.edit().putInt("gw_w", 100).putInt("gw_h", 100).putInt("gw_x", 50).putInt("gw_y", 0).apply()
                openWindowSizes()
            }
            .setPositiveButton("Listo", null).create()
        glass(d)
        d.show()
        dialog = d
    }

    // ───────────────────────── contador de FPS ─────────────────────────

    private fun openShizuku() {
        val i = pm.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i == null) {
            toast("Instala la app Shizuku primero")
        } else {
            try {
                skipRandom = true
                startActivity(i)
            } catch (_: Exception) {
                toast("No se pudo abrir Shizuku")
            }
        }
    }

    private fun openFpsSettings() {
        val running = FpsMonitor.shizukuRunning()
        val granted = FpsMonitor.shizukuGranted()
        val overlay = FpsMonitor.canOverlay(this)
        val on = prefs.getBoolean("fps_games", true)
        val corners = arrayOf("arriba izquierda", "arriba derecha", "abajo izquierda", "abajo derecha")
        val pos = prefs.getInt("fps_pos", 0).coerceIn(0, 3)
        val rotMode = rotateMode()
        val usage = hasUsageAccess()
        val labels = arrayOf(
            "Shizuku: " + (if (!running) "no está activo (toca para abrirlo)" else if (!granted) "toca para dar permiso" else "listo"),
            "Superposición sobre otras apps: " + (if (overlay) "lista" else "toca para activarla"),
            "Contador en juegos: " + (if (on) "sí" else "no"),
            "Esquina de la ventana: " + corners[pos],
            "Elementos del contador…",
            "Probar el contador (diagnóstico)…",
            "Reacomodar la ventana al girar: " + arrayOf(
                "no",
                "sí, seguro (solo si confirma que el juego sigue abierto)",
                "sí, siempre (puede reabrir un juego que cerraste)"
            )[rotMode] + " — toca para cambiar",
            "Acceso de uso (saber si el juego sigue abierto): " + (if (usage) "listo" else "toca para activarlo")
        )
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Contador de FPS").setItems(labels) { _, which ->
            when (which) {
                0 -> {
                    if (!running) openShizuku() else if (!granted) FpsMonitor.requestShizuku(100)
                }
                1 -> {
                    if (!overlay) {
                        try {
                            skipRandom = true
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
                        } catch (_: Exception) {
                            toast("No se pudo abrir ese ajuste")
                        }
                    }
                }
                2 -> prefs.edit().putBoolean("fps_games", !on).apply()
                3 -> prefs.edit().putInt("fps_pos", (pos + 1) % 4).apply()
                4 -> fpsItemsDialog()
                5 -> fpsDiagnose()
                6 -> {
                    val next = (rotMode + 1) % 3
                    prefs.edit().putBoolean("rotate_fix", next != 0).putInt("rotate_mode", if (next == 0) 1 else next).apply()
                    toast(arrayOf("Al girar: no reacomodar", "Al girar: reacomodar (seguro)", "Al girar: reacomodar siempre")[next])
                }
                7 -> {
                    if (!usage) {
                        try {
                            skipRandom = true
                            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                        } catch (_: Exception) {
                            toast("No se pudo abrir ese ajuste")
                        }
                    }
                }
            }
        }.create()
        glass(d)
        d.show()
        dialog = d
    }

    private fun fpsItemsDialog() {
        val names = arrayOf("FPS", "CPU (uso y temperatura)", "GPU (uso)", "RAM", "Temperatura de la batería", "Batería (%)")
        val bits = intArrayOf(
            FpsMonitor.F_FPS, FpsMonitor.F_CPU, FpsMonitor.F_GPU,
            FpsMonitor.F_RAM, FpsMonitor.F_TEMP, FpsMonitor.F_BAT
        )
        var mask = prefs.getInt("fps_items", FpsMonitor.DEFAULT_ITEMS)
        val checked = BooleanArray(bits.size) { (mask and bits[it]) != 0 }
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Elementos del contador")
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                mask = if (isChecked) (mask or bits[which]) else (mask and bits[which].inv())
                prefs.edit().putInt("fps_items", mask).apply()
            }
            .setPositiveButton("Listo", null).create()
        glass(d)
        d.show()
        dialog = d
    }

    private fun fpsDiagnose() {
        toast("Probando…")
        val pkg = lastPkg
        Thread {
            val text = FpsMonitor.diagnose(applicationContext, pkg) +
                    "\n\nÚltimo reacomodo al girar:\n" +
                    rotLog.ifEmpty { "(todavía no has girado la pantalla con un juego abierto en ventana)" }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val tv = TextView(this)
                tv.text = text
                tv.setTextColor(cText())
                tv.textSize = 13f
                tv.setTextIsSelectable(true)
                tv.setPadding(dp(20), dp(12), dp(20), dp(8))
                val sv = ScrollView(this)
                sv.addView(tv)
                dialog?.dismiss()
                val d = AlertDialog.Builder(this).setTitle("Diagnóstico").setView(sv)
                    .setPositiveButton("Listo", null).create()
                glass(d)
                d.show()
                dialog = d
            }
        }.start()
    }

    // ───────────────────────── cristal (estilo Windows moderno) ─────────────────────────

    private fun blurOk(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return false
        return try {
            windowManager.isCrossWindowBlurEnabled
        } catch (_: Throwable) {
            false
        }
    }

    /** Panel translúcido con esquinas redondeadas. Con desenfoque real si el sistema lo permite; si no, un poco más opaco. */
    private fun glass(d: AlertDialog) {
        val w = d.window ?: return
        val blur = blurOk()
        val base = if (dark()) 0x101418 else 0xF3F3F3
        val alpha = if (blur) 0xB0 else 0xDD
        w.setBackgroundDrawable(GradientDrawable().apply {
            setColor((alpha shl 24) or base)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), cStroke())
        })
        w.setDimAmount(if (blur) 0.18f else 0.12f)
        if (blur && Build.VERSION.SDK_INT >= 31) {
            try {
                w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                val lp = w.attributes
                lp.blurBehindRadius = dp(18)
                w.attributes = lp
            } catch (_: Throwable) {
            }
        }
        d.setOnShowListener {
            if (animsOn()) {
                val dv = w.decorView
                dv.alpha = 0f
                dv.scaleX = 0.96f
                dv.scaleY = 0.96f
                dv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(ANIM_MS).setInterpolator(ease).start()
            }
        }
    }

    private fun roundBg(color: Int, r: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun cardBox(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundBg(cCard(), 10)
        return c
    }

    private fun addRow(card: LinearLayout, row: View) {
        if (card.childCount > 0) {
            val line = View(this)
            line.setBackgroundColor(cStroke())
            val lp = LinearLayout.LayoutParams(MATCH, 1)
            lp.leftMargin = dp(14)
            card.addView(line, lp)
        }
        card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun rowTexts(title: String, sub: String?): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.setTextColor(cText())
        t.textSize = 15f
        col.addView(t)
        if (sub != null) {
            val st = TextView(this)
            st.text = sub
            st.setTextColor(cSub())
            st.textSize = 12f
            col.addView(st)
        }
        return col
    }

    private fun navRow(card: LinearLayout, title: String, sub: String?, onClick: () -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(12), dp(14), dp(12))
        row.addView(rowTexts(title, sub), LinearLayout.LayoutParams(0, WRAP, 1f))
        val chev = TextView(this)
        chev.text = "›"
        chev.textSize = 22f
        chev.setTextColor(cSub())
        row.addView(chev)
        row.background = pressBg()
        row.setOnClickListener { onClick() }
        addRow(card, row)
    }

    /** Fila con interruptor. onChange devuelve false si el cambio no se acepta (el interruptor vuelve a como estaba). */
    private fun switchRow(card: LinearLayout, title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Boolean) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(10), dp(14), dp(10))
        row.addView(rowTexts(title, sub), LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this)
        sw.isChecked = checked
        var reverting = false
        sw.setOnCheckedChangeListener { _, c ->
            if (!reverting && !onChange(c)) {
                reverting = true
                sw.isChecked = !c
                reverting = false
            }
        }
        row.addView(sw)
        row.background = pressBg()
        row.setOnClickListener { sw.toggle() }
        addRow(card, row)
    }

    private fun prefSwitch(card: LinearLayout, title: String, sub: String?, key: String, def: Boolean, after: () -> Unit = {}) {
        switchRow(card, title, sub, prefs.getBoolean(key, def)) { c ->
            prefs.edit().putBoolean(key, c).apply()
            after()
            true
        }
    }

    // ───────────────────────── ajustes ─────────────────────────

    private fun openSettings() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(2), dp(16), dp(10))

        fun section(title: String, build: (LinearLayout) -> Unit) {
            sectionTitle(box, title)
            val c = cardBox()
            build(c)
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(6)
            box.addView(c, lp)
        }

        section("Ventanas") { c ->
            prefSwitch(c, "Abrir apps en ventana", null, "windowed", true)
            prefSwitch(c, "Juegos en ventana", null, "game_window", true)
            navRow(c, "Tamaño de ventanas", "Con vista previa en vivo") { openWindowSizes() }
            prefSwitch(c, "Fondo estático al abrir un juego", "Ahorra batería y rendimiento", "freeze_bg", true)
            navRow(c, "Contador de FPS", null) { openFpsSettings() }
        }
        section("Fondos") { c ->
            navRow(c, "Fondos", "Fondo 1, Fondo 2 y oscurecer") { openBackgroundMenu() }
            switchRow(c, "Alternar fondos al azar", "Al abrir el launcher o volver a él", randomOn()) { on ->
                if (on && !hasSlot2()) {
                    toast("Primero elige el Fondo 2")
                    false
                } else {
                    prefs.edit().putBoolean("bg_random", on).apply()
                    true
                }
            }
        }
        section("Iconos") { c ->
            prefSwitch(c, "Iconos estilo Windows", "Transparentes, sin la placa de Android", "win_icons", true) { refreshDesktop() }
            navRow(c, "Icono de acceso directo", "Insignia en la esquina de cada icono") { openBadgeSettings() }
        }
        section("Animaciones") { c ->
            prefSwitch(c, "Física al mover iconos", "Se inclinan como si el aire los empujara", "phys", true)
            prefSwitch(c, "Vibración suave al soltar", null, "haptic_drop", true)
            prefSwitch(c, "Reducir animaciones", "Sin transiciones ni física", "reduce_anim", false)
        }
        if (pageCount > 1) {
            section("Páginas") { c ->
                navRow(c, "Quitar esta página", null) {
                    dialog?.dismiss()
                    removePage()
                }
            }
        }

        val sv = ScrollView(this)
        sv.addView(box)
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Ajustes").setView(sv)
            .setPositiveButton("Listo", null).create()
        glass(d)
        d.show()
        val dm = resources.displayMetrics
        d.window?.setLayout(minOf((dm.widthPixels * 0.92f).toInt(), dp(520)), WRAP)
        dialog = d
    }

    // ───────────────────────── icono de acceso directo (insignia) ─────────────────────────

    private fun badgeBitmap(): Bitmap {
        val name = prefs.getString("badge_custom", null)
        val key = name ?: ""
        var b = badgeBmp
        if (b == null || badgeKey != key) {
            b = if (name != null) BitmapFactory.decodeFile(File(filesDir, name).path) else null
            if (b == null) b = BitmapFactory.decodeResource(resources, R.drawable.badge_shortcut)
            badgeBmp = b
            badgeKey = key
        }
        return b!!
    }

    private fun openBadgeSettings() {
        val on = prefs.getBoolean("badge_on", true)
        val custom = prefs.getString("badge_custom", null) != null
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        items.add("Mostrar el icono: " + (if (on) "sí" else "no"))
        acts.add {
            prefs.edit().putBoolean("badge_on", !on).apply()
            refreshDesktop()
        }
        items.add("Cambiar por otra imagen…")
        acts.add { pickFile("image/*", REQ_BADGE) }
        if (custom) {
            items.add("Restaurar el original")
            acts.add { resetBadge() }
        }
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Icono de acceso directo")
            .setItems(items.toTypedArray()) { _, which -> acts[which]() }.create()
        glass(d)
        d.show()
        dialog = d
    }

    private fun handleBadgeResult(data: Intent) {
        val uri = data.data ?: return
        val name = importIcon(uri)
        if (name == null) {
            toast("No se pudo usar esa imagen")
            return
        }
        prefs.getString("badge_custom", null)?.let { File(filesDir, it).delete() }
        prefs.edit().putString("badge_custom", name).putBoolean("badge_on", true).apply()
        refreshDesktop()
    }

    private fun resetBadge() {
        prefs.getString("badge_custom", null)?.let { File(filesDir, it).delete() }
        prefs.edit().remove("badge_custom").apply()
        refreshDesktop()
    }

    // ───────────────────────── enlace personalizado y nombres ─────────────────────────

    private fun letterIcon(label: String): Bitmap {
        val size = 192
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val colors = intArrayOf(
            0xFF0F6CBD.toInt(), 0xFF107C10.toInt(), 0xFFC239B3.toInt(),
            0xFFCA5010.toInt(), 0xFF00B7C3.toInt(), 0xFF8764B8.toInt()
        )
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = colors[(label.hashCode() and 0x7fffffff) % colors.size]
        c.drawRoundRect(RectF(12f, 12f, size - 12f, size - 12f), 40f, 40f, p)
        p.color = Color.WHITE
        p.textSize = 100f
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        c.drawText(label.trim().take(1).uppercase(), size / 2f, size / 2f + 35f, p)
        return bmp
    }

    private fun addCustomLink(x: Float, y: Float) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(4))
        val name = EditText(this)
        name.hint = "Nombre"
        name.setSingleLine()
        name.setTextColor(cText())
        name.setHintTextColor(cSub())
        val url = EditText(this)
        url.hint = "Enlace (por ejemplo youtube.com)"
        url.setSingleLine()
        url.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        url.setTextColor(cText())
        url.setHintTextColor(cSub())
        box.addView(name, LinearLayout.LayoutParams(MATCH, WRAP))
        box.addView(url, LinearLayout.LayoutParams(MATCH, WRAP))
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Acceso directo personalizado").setView(box)
            .setPositiveButton("Agregar") { _, _ ->
                var link = url.text.toString().trim()
                if (link.isEmpty()) {
                    toast("Escribe un enlace")
                } else {
                    if (!link.contains("://")) link = "https://" + link
                    val shown = name.text.toString().trim().ifEmpty { Uri.parse(link).host ?: link }
                    val pin = Pin(1, "", "")
                    pin.label = shown
                    pin.data = Intent(Intent.ACTION_VIEW, Uri.parse(link)).toUri(0)
                    pin.base = saveBitmap(letterIcon(shown))
                    addPin(pin, x, y)
                }
            }
            .setNegativeButton("Cancelar", null).create()
        glass(d)
        d.show()
        dialog = d
    }

    private fun renameDialog(pin: Pin) {
        val et = EditText(this)
        et.setSingleLine()
        et.setText(labelOf(pin) ?: "")
        et.setSelectAllOnFocus(true)
        et.setTextColor(cText())
        val box = LinearLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), dp(4))
        box.addView(et, LinearLayout.LayoutParams(MATCH, WRAP))
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Cambiar nombre").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty() || pin.kind == 0) {
                    pin.label = if (t.isEmpty()) null else t // vacío = nombre original de la app
                    save()
                    refreshDesktop()
                }
            }
            .setNegativeButton("Cancelar", null).create()
        glass(d)
        d.show()
        dialog = d
    }

    // ───────────────────────── fondos ─────────────────────────

    private fun kType(s: Int): String = if (s == 2) "bg2_type" else "bg_type"
    private fun kValue(s: Int): String = if (s == 2) "bg2_value" else "bg_value"
    private fun kColor(s: Int): String = if (s == 2) "bg2_color" else "bg_color"

    private fun randomOn(): Boolean = prefs.getBoolean("bg_random", false)
    private fun hasSlot2(): Boolean = prefs.getString("bg2_type", null) != null
    private fun scrimPct(): Int = prefs.getInt("scrim", 15).coerceIn(0, 100)

    private fun applyScrim() {
        scrim.setBackgroundColor(Color.argb(scrimPct() * 255 / 100, 0, 0, 0))
    }

    private fun openBackgroundMenu() {
        val muted = prefs.getBoolean("muted", false)
        val rnd = randomOn()
        val items = arrayOf(
            "Fondo 1…",
            "Fondo 2…" + (if (hasSlot2()) "" else " (sin elegir)"),
            "Alternar al azar al abrir: " + (if (rnd) "sí" else "no"),
            "Oscurecer fondo: " + scrimPct() + "%",
            if (muted) "Sonido del video: apagado" else "Sonido del video: encendido"
        )
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Fondos").setItems(items) { _, which ->
            when (which) {
                0 -> backgroundSlotMenu(1)
                1 -> backgroundSlotMenu(2)
                2 -> {
                    if (!rnd && !hasSlot2()) {
                        toast("Primero elige el Fondo 2")
                    } else {
                        prefs.edit().putBoolean("bg_random", !rnd).apply()
                    }
                }
                3 -> scrimDialog()
                4 -> {
                    prefs.edit().putBoolean("muted", !muted).apply()
                    bgVideo.setMuted(!muted)
                }
            }
        }.create()
        glass(d)
        d.show()
        dialog = d
    }

    private fun backgroundSlotMenu(slot: Int) {
        editSlot = slot
        val items = arrayOf("Color sólido", "Imagen o GIF animado", "Video (con audio)")
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Fondo " + slot).setItems(items) { _, which ->
            when (which) {
                0 -> pickColor()
                1 -> pickFile("image/*", REQ_IMAGE)
                2 -> pickFile("video/*", REQ_VIDEO)
            }
        }.create()
        glass(d)
        d.show()
        dialog = d
    }

    private fun scrimDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(8))
        addSlider(box, "Oscurecer", 0, scrimPct()) {
            prefs.edit().putInt("scrim", it).apply()
            applyScrim()
        }
        hintText(box, "Una capa negra suave sobre el fondo para que los nombres se lean con cualquier imagen.")
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Oscurecer fondo").setView(box)
            .setPositiveButton("Listo", null).create()
        glass(d)
        d.show()
        dialog = d
    }

    private fun pickColor() {
        val names = arrayOf("Verde azulado", "Azul", "Negro", "Gris oscuro", "Morado", "Vino")
        val cols = intArrayOf(
            0xFF429C92.toInt(), 0xFF0F6CBD.toInt(), 0xFF000000.toInt(),
            0xFF2B2B2B.toInt(), 0xFF5B3A8C.toInt(), 0xFF7A1F3D.toInt()
        )
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Color").setItems(names) { _, which ->
            prefs.edit().putString(kType(editSlot), "color").putInt(kColor(editSlot), cols[which]).apply()
            applyBackground(editSlot)
        }.create()
        glass(d)
        d.show()
        dialog = d
    }

    private fun pickFile(mime: String, req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            skipRandom = true
            startActivityForResult(i, req)
        } catch (_: Exception) {
            toast("No hay selector de archivos")
        }
    }

    private fun applyBackground(slot: Int = curSlot) {
        curSlot = slot
        frozen = false
        val type = prefs.getString(kType(slot), "color")
        val uri = prefs.getString(kValue(slot), null)?.let { Uri.parse(it) }
        root.setBackgroundColor(prefs.getInt(kColor(slot), DEFAULT_BG))

        bgImage.animate().cancel()
        bgImage.alpha = 1f
        bgImage.setImageDrawable(null)
        bgImage.visibility = View.GONE
        bgVideo.setSource(null, false)
        bgVideo.visibility = View.GONE

        if (uri == null || type == "color") return
        if (type == "video") {
            bgVideo.visibility = View.VISIBLE
            bgVideo.setSource(uri, prefs.getBoolean("muted", false))
        } else {
            loadImage(uri)
        }
    }

    /** Cambia de un fondo al otro con transición suave: se desvanece el actual y aparece el nuevo. */
    private fun switchBackground(slot: Int) {
        if (slot == curSlot) return
        if (!animsOn()) {
            applyBackground(slot)
            return
        }
        val from = prefs.getInt(kColor(curSlot), DEFAULT_BG)
        bgLayer.animate().cancel()
        bgLayer.animate().alpha(0f).setDuration(220).setInterpolator(ease).withEndAction {
            applyBackground(slot)
            val to = prefs.getInt(kColor(slot), DEFAULT_BG)
            if (from != to) {
                root.setBackgroundColor(from)
                val va = ValueAnimator.ofArgb(from, to)
                va.duration = 450
                va.addUpdateListener { a -> root.setBackgroundColor(a.animatedValue as Int) }
                va.start()
            }
            bgLayer.animate().alpha(1f).setDuration(450).setInterpolator(ease).start()
        }.start()
    }

    private fun loadImage(uri: Uri) {
        val dm = resources.displayMetrics
        val slot = curSlot
        Thread {
            try {
                val src = ImageDecoder.createSource(contentResolver, uri)
                val d = ImageDecoder.decodeDrawable(src) { dec, info, _ ->
                    val w = info.size.width
                    val h = info.size.height
                    val s = maxOf(dm.widthPixels.toFloat() / w, dm.heightPixels.toFloat() / h)
                    if (s < 1f) dec.setTargetSize(maxOf(1, (w * s).toInt()), maxOf(1, (h * s).toInt()))
                }
                runOnUiThread {
                    if (curSlot != slot || prefs.getString(kType(slot), "") != "image" ||
                        prefs.getString(kValue(slot), null) != uri.toString()
                    ) return@runOnUiThread
                    bgImage.setImageDrawable(d)
                    bgImage.visibility = View.VISIBLE
                    if (animsOn()) {
                        bgImage.alpha = 0f
                        bgImage.animate().alpha(1f).setDuration(ANIM_MS + 150).setInterpolator(ease).start()
                    }
                    if (d is AnimatedImageDrawable) {
                        d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                        d.start()
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { toast("No se pudo cargar la imagen") }
            }
        }.start()
    }
}
