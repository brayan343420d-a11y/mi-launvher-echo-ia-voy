package com.winlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupWindow
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_IMAGE = 1
private const val REQ_VIDEO = 2
private const val DEFAULT_BG = 0xFF429C92.toInt()

/** Un icono puesto en el escritorio. fx/fy = posición como fracción (0..1) del espacio libre. */
class Pin(val pkg: String, val cls: String, var fx: Float, var fy: Float)

class AppItem(val label: String, val pkg: String, val cls: String, val icon: Drawable)

class MItem(val label: String, val action: () -> Unit)

/** Escritorio: coloca cada hijo según su Pin (así sobrevive a rotar la pantalla). */
class Desktop(ctx: Context) : FrameLayout(ctx) {
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val pin = v.tag as? Pin ?: continue
            val w = v.measuredWidth
            val h = v.measuredHeight
            val x = (pin.fx * (width - w)).toInt().coerceAtLeast(0)
            val y = (pin.fy * (height - h)).toInt().coerceAtLeast(0)
            v.layout(x, y, x + w, y + h)
        }
    }
}

/** Fondo de video con audio, recortado para llenar la pantalla. Se libera por completo al salir del launcher. */
class VideoBackground(ctx: Context) : TextureView(ctx), TextureView.SurfaceTextureListener {
    private var player: MediaPlayer? = null
    private var surface: Surface? = null
    private var uri: Uri? = null
    private var muted = false
    private var vw = 0
    private var vh = 0

    init {
        surfaceTextureListener = this
    }

    fun setSource(u: Uri?, mute: Boolean) {
        release()
        uri = u
        muted = mute
        if (u != null) startPlayback()
    }

    fun setMuted(m: Boolean) {
        muted = m
        val v = if (m) 0f else 1f
        try {
            player?.setVolume(v, v)
        } catch (_: Exception) {
        }
    }

    fun startPlayback() {
        val u = uri ?: return
        val s = surface ?: return
        if (player != null) return
        try {
            val p = MediaPlayer()
            player = p
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            )
            p.setDataSource(context, u)
            p.setSurface(s)
            p.isLooping = true
            val v = if (muted) 0f else 1f
            p.setVolume(v, v)
            p.setOnVideoSizeChangedListener { _, w, h ->
                vw = w
                vh = h
                fit()
            }
            p.setOnPreparedListener { it.start() }
            p.setOnErrorListener { _, _, _ ->
                release()
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            release()
        }
    }

    fun stopPlayback() {
        release()
    }

    private fun release() {
        val p = player
        player = null
        if (p != null) {
            try {
                p.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun fit() {
        if (vw == 0 || vh == 0 || width == 0 || height == 0) return
        val s = maxOf(width.toFloat() / vw, height.toFloat() / vh)
        val m = Matrix()
        m.setScale(vw * s / width, vh * s / height, width / 2f, height / 2f)
        setTransform(m)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        surface = Surface(st)
        startPlayback()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
        fit()
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        release()
        surface?.release()
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
}

/** Logo de Windows dibujado a mano (sin recursos). */
class WinLogo(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF7CC4FF.toInt() }
    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height) * 0.42f
        val g = s * 0.09f
        val q = (s - g) / 2f
        val x = (width - s) / 2f
        val y = (height - s) / 2f
        cv.drawRect(x, y, x + q, y + q, p)
        cv.drawRect(x + q + g, y, x + s, y + q, p)
        cv.drawRect(x, y + q + g, x + q, y + s, p)
        cv.drawRect(x + q + g, y + q + g, x + s, y + s, p)
    }
}

/** Lupa dibujada a mano. */
class SearchIcon(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height) * 0.38f
        p.strokeWidth = s * 0.12f
        val cx = width / 2f - s * 0.08f
        val cy = height / 2f - s * 0.08f
        val r = s * 0.36f
        cv.drawCircle(cx, cy, r, p)
        cv.drawLine(cx + r * 0.72f, cy + r * 0.72f, cx + s * 0.55f, cy + s * 0.55f, p)
    }
}

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var bgImage: ImageView
    private lateinit var bgVideo: VideoBackground
    private lateinit var column: LinearLayout
    private lateinit var desktop: Desktop
    private lateinit var taskbar: LinearLayout

    private val pins = ArrayList<Pin>()
    private var popup: PopupWindow? = null
    private var dialog: AlertDialog? = null

    private val pm: PackageManager get() = packageManager

    // ───────────────────────── ciclo de vida ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("wl", MODE_PRIVATE)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        loadPins()
        buildUi()
        applyBackground()
    }

    override fun onStart() {
        super.onStart()
        refreshDesktop()
        bgVideo.startPlayback()
        (bgImage.drawable as? AnimatedImageDrawable)?.start()
    }

    override fun onStop() {
        super.onStop()
        bgVideo.stopPlayback()
        (bgImage.drawable as? AnimatedImageDrawable)?.stop()
        popup?.dismiss()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        popup?.dismiss()
        dialog?.dismiss()
    }

    override fun onBackPressed() {
        // Un launcher no se cierra con "atrás"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        prefs.edit()
            .putString("bg_type", if (requestCode == REQ_VIDEO) "video" else "image")
            .putString("bg_value", uri.toString())
            .apply()
        applyBackground()
    }

    // ───────────────────────── interfaz ─────────────────────────

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun pressBg(): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(0x33FFFFFF))
        addState(intArrayOf(), ColorDrawable(0))
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(prefs.getInt("bg_color", DEFAULT_BG))

        bgImage = ImageView(this)
        bgImage.scaleType = ImageView.ScaleType.CENTER_CROP
        bgImage.visibility = View.GONE
        root.addView(bgImage, MATCH, MATCH)

        bgVideo = VideoBackground(this)
        bgVideo.visibility = View.GONE
        root.addView(bgVideo, MATCH, MATCH)

        column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL

        desktop = Desktop(this)
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onLongPress(e: MotionEvent) {
                val x = e.x
                val y = e.y
                val rx = e.rawX
                val ry = e.rawY
                desktop.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showMenu(
                    rx, ry, listOf(
                        MItem("Aplicaciones") { pickToAdd(x, y) },
                        MItem("Fondos") { openBackgroundMenu() }
                    )
                )
            }
        })
        desktop.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            true
        }
        column.addView(desktop, LinearLayout.LayoutParams(MATCH, 0, 1f))

        taskbar = buildTaskbar()
        column.addView(taskbar, LinearLayout.LayoutParams(MATCH, dp(48)))
        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        root.setOnApplyWindowInsetsListener { _, ins ->
            column.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, 0)
            val bottom = ins.systemWindowInsetBottom
            taskbar.setPadding(0, 0, 0, bottom)
            (taskbar.layoutParams as LinearLayout.LayoutParams).height = dp(48) + bottom
            taskbar.requestLayout()
            ins
        }
        setContentView(root)
    }

    private fun buildTaskbar(): LinearLayout {
        val tb = LinearLayout(this)
        tb.orientation = LinearLayout.HORIZONTAL
        tb.gravity = Gravity.CENTER_VERTICAL
        tb.setBackgroundColor(0xD9141A1E.toInt())

        val start = WinLogo(this)
        start.background = pressBg()
        start.setOnClickListener { openAppList(false) }
        tb.addView(start, LinearLayout.LayoutParams(dp(52), MATCH))

        val search = SearchIcon(this)
        search.background = pressBg()
        search.setOnClickListener { openAppList(true) }
        tb.addView(search, LinearLayout.LayoutParams(dp(48), MATCH))

        tb.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        val clock = LinearLayout(this)
        clock.orientation = LinearLayout.VERTICAL
        clock.gravity = Gravity.CENTER
        clock.setPadding(dp(8), 0, dp(14), 0)

        val time = TextClock(this)
        time.setTextColor(Color.WHITE)
        time.textSize = 12f
        time.gravity = Gravity.CENTER

        val date = TextClock(this)
        date.setTextColor(Color.WHITE)
        date.textSize = 12f
        date.gravity = Gravity.CENTER
        date.format12Hour = "d/M/yy"
        date.format24Hour = "d/M/yy"

        clock.addView(time, LinearLayout.LayoutParams(WRAP, WRAP))
        clock.addView(date, LinearLayout.LayoutParams(WRAP, WRAP))
        tb.addView(clock, LinearLayout.LayoutParams(WRAP, MATCH))
        return tb
    }

    // ───────────────────────── menú emergente ─────────────────────────

    private fun showMenu(rx: Float, ry: Float, items: List<MItem>) {
        popup?.dismiss()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(6), 0, dp(6))
        box.background = GradientDrawable().apply {
            setColor(0xF2202428.toInt())
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), 0x33FFFFFF)
        }
        val pw = PopupWindow(box, WRAP, WRAP, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        for (item in items) {
            val tv = TextView(this)
            tv.text = item.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 15f
            tv.setPadding(dp(20), dp(12), dp(32), dp(12))
            tv.background = pressBg()
            tv.setOnClickListener {
                pw.dismiss()
                item.action()
            }
            box.addView(tv)
        }
        box.measure(0, 0)
        val dm = resources.displayMetrics
        val x = rx.toInt().coerceIn(0, (dm.widthPixels - box.measuredWidth).coerceAtLeast(0))
        val y = ry.toInt().coerceIn(0, (dm.heightPixels - box.measuredHeight).coerceAtLeast(0))
        pw.showAtLocation(root, Gravity.TOP or Gravity.START, x, y)
        popup = pw
    }

    // ───────────────────────── apps en el escritorio ─────────────────────────

    private fun loadPins() {
        pins.clear()
        try {
            val arr = JSONArray(prefs.getString("apps", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                pins.add(Pin(o.getString("p"), o.getString("c"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat()))
            }
        } catch (_: Exception) {
        }
    }

    private fun save() {
        val arr = JSONArray()
        for (p in pins) {
            arr.put(JSONObject().put("p", p.pkg).put("c", p.cls).put("x", p.fx.toDouble()).put("y", p.fy.toDouble()))
        }
        prefs.edit().putString("apps", arr.toString()).apply()
    }

    private fun refreshDesktop() {
        desktop.removeAllViews()
        var changed = false
        val iter = pins.iterator()
        while (iter.hasNext()) {
            val pin = iter.next()
            val v = iconView(pin)
            if (v == null) {
                iter.remove() // la app ya no está instalada
                changed = true
            } else {
                desktop.addView(v, FrameLayout.LayoutParams(WRAP, WRAP))
            }
        }
        if (changed) save()
    }

    private fun iconView(pin: Pin): View? {
        val ai = try {
            pm.getActivityInfo(ComponentName(pin.pkg, pin.cls), 0)
        } catch (_: Exception) {
            return null
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(8), dp(10), dp(8))

        val icon = ImageView(this)
        icon.setImageDrawable(ai.loadIcon(pm))
        row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))

        val label = TextView(this)
        label.text = ai.loadLabel(pm)
        label.setTextColor(Color.WHITE)
        label.textSize = 13f
        label.setTypeface(label.typeface, Typeface.BOLD)
        label.setSingleLine()
        label.ellipsize = TextUtils.TruncateAt.END
        label.maxWidth = dp(130)
        label.setShadowLayer(4f, 0f, 1f, Color.BLACK)
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.leftMargin = dp(8)
        row.addView(label, lp)

        row.tag = pin
        row.setOnTouchListener(IconTouch(pin, row))
        return row
    }

    private fun addPin(a: AppItem, x: Float, y: Float) {
        val pin = Pin(a.pkg, a.cls, 0f, 0f)
        val v = iconView(pin) ?: return
        v.measure(0, 0)
        val w = v.measuredWidth
        val h = v.measuredHeight
        pin.fx = ((x - w / 2f) / (desktop.width - w).coerceAtLeast(1)).coerceIn(0f, 1f)
        pin.fy = ((y - h / 2f) / (desktop.height - h).coerceAtLeast(1)).coerceIn(0f, 1f)
        pins.add(pin)
        desktop.addView(v, FrameLayout.LayoutParams(WRAP, WRAP))
        save()
    }

    private fun removePin(pin: Pin, v: View) {
        pins.remove(pin)
        desktop.removeView(v)
        save()
    }

    private fun dragTo(pin: Pin, v: View, left: Float, top: Float) {
        val loc = IntArray(2)
        desktop.getLocationOnScreen(loc)
        pin.fx = ((left - loc[0]) / (desktop.width - v.width).coerceAtLeast(1)).coerceIn(0f, 1f)
        pin.fy = ((top - loc[1]) / (desktop.height - v.height).coerceAtLeast(1)).coerceIn(0f, 1f)
        desktop.requestLayout()
    }

    /** Toque = abrir. Mantener presionado = arrastrar. Mantener y soltar sin mover = menú "Quitar". */
    private inner class IconTouch(val pin: Pin, val v: View) : View.OnTouchListener {
        private var dragging = false
        private var cancelled = false
        private var moved = false
        private var downX = 0f
        private var downY = 0f
        private var offX = 0f
        private var offY = 0f
        private val slop = ViewConfiguration.get(this@MainActivity).scaledTouchSlop

        private val longPress = Runnable {
            dragging = true
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            v.parent?.requestDisallowInterceptTouchEvent(true)
            v.alpha = 0.7f
        }

        override fun onTouch(view: View, ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    cancelled = false
                    moved = false
                    downX = ev.rawX
                    downY = ev.rawY
                    offX = ev.x
                    offY = ev.y
                    v.setBackgroundColor(0x33FFFFFF)
                    v.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                }
                MotionEvent.ACTION_MOVE -> {
                    val far = abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop
                    if (dragging) {
                        if (far) moved = true
                        dragTo(pin, v, ev.rawX - offX, ev.rawY - offY)
                    } else if (far) {
                        cancelled = true
                        v.removeCallbacks(longPress)
                        v.background = null
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.removeCallbacks(longPress)
                    v.background = null
                    v.alpha = 1f
                    if (dragging) {
                        if (moved) save()
                        else showMenu(ev.rawX, ev.rawY, listOf(MItem("Quitar") { removePin(pin, v) }))
                    } else if (!cancelled) {
                        launch(pin.pkg, pin.cls)
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(longPress)
                    v.background = null
                    v.alpha = 1f
                }
            }
            return true
        }
    }

    private fun launch(pkg: String, cls: String) {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(pkg, cls))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (_: Exception) {
            toast("No se pudo abrir la app")
        }
    }

    // ───────────────────────── lista de apps ─────────────────────────

    private fun loadApps(cb: (List<AppItem>) -> Unit) {
        Thread {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(i, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    AppItem(ri.loadLabel(pm).toString(), ri.activityInfo.packageName, ri.activityInfo.name, ri.loadIcon(pm))
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread { cb(list) }
        }.start()
    }

    private fun pickToAdd(x: Float, y: Float) {
        loadApps { apps -> showAppList(apps, false) { app -> addPin(app, x, y) } }
    }

    private fun openAppList(focusSearch: Boolean) {
        loadApps { apps -> showAppList(apps, focusSearch) { app -> launch(app.pkg, app.cls) } }
    }

    private fun showAppList(apps: List<AppItem>, focusSearch: Boolean, onPick: (AppItem) -> Unit) {
        if (isFinishing || isDestroyed) return
        dialog?.dismiss()
        var shown: List<AppItem> = apps

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(12), dp(12), dp(8))

        val search = EditText(this)
        search.hint = "Buscar"
        search.setSingleLine()
        search.setTextColor(Color.WHITE)
        search.setHintTextColor(0x88FFFFFF.toInt())

        val list = ListView(this)
        list.divider = null

        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(position: Int): Any = shown[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val row: LinearLayout = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                    addView(ImageView(context), LinearLayout.LayoutParams(dp(36), dp(36)))
                    val tv = TextView(context)
                    tv.setTextColor(Color.WHITE)
                    tv.textSize = 16f
                    tv.setSingleLine()
                    tv.ellipsize = TextUtils.TruncateAt.END
                    val lp = LinearLayout.LayoutParams(WRAP, WRAP)
                    lp.leftMargin = dp(14)
                    addView(tv, lp)
                }
                val a = shown[position]
                (row.getChildAt(0) as ImageView).setImageDrawable(a.icon)
                (row.getChildAt(1) as TextView).text = a.label
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val a = shown[pos]
            dialog?.dismiss()
            onPick(a)
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString().trim().lowercase()
                shown = if (q.isEmpty()) apps else apps.filter { it.label.lowercase().contains(q) }
                adapter.notifyDataSetChanged()
            }
        })

        box.addView(search, LinearLayout.LayoutParams(MATCH, WRAP))
        val dm = resources.displayMetrics
        box.addView(list, LinearLayout.LayoutParams(MATCH, (dm.heightPixels * 0.6f).toInt()))

        val d = AlertDialog.Builder(this).setView(box).create()
        d.window?.setSoftInputMode(
            if (focusSearch) WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
            else WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        )
        if (focusSearch) search.requestFocus()
        d.show()
        d.window?.setLayout(minOf((dm.widthPixels * 0.92f).toInt(), dp(520)), WRAP)
        dialog = d
    }

    // ───────────────────────── fondos ─────────────────────────

    private fun openBackgroundMenu() {
        val muted = prefs.getBoolean("muted", false)
        val items = arrayOf(
            "Color sólido",
            "Imagen o GIF animado",
            "Video (con audio)",
            if (muted) "Sonido del video: apagado" else "Sonido del video: encendido"
        )
        dialog?.dismiss()
        dialog = AlertDialog.Builder(this).setTitle("Fondos").setItems(items) { _, which ->
            when (which) {
                0 -> pickColor()
                1 -> pickFile("image/*", REQ_IMAGE)
                2 -> pickFile("video/*", REQ_VIDEO)
                3 -> {
                    prefs.edit().putBoolean("muted", !muted).apply()
                    bgVideo.setMuted(!muted)
                }
            }
        }.show()
    }

    private fun pickColor() {
        val names = arrayOf("Verde azulado", "Azul", "Negro", "Gris oscuro", "Morado", "Vino")
        val cols = intArrayOf(
            0xFF429C92.toInt(), 0xFF0F6CBD.toInt(), 0xFF000000.toInt(),
            0xFF2B2B2B.toInt(), 0xFF5B3A8C.toInt(), 0xFF7A1F3D.toInt()
        )
        dialog?.dismiss()
        dialog = AlertDialog.Builder(this).setTitle("Color").setItems(names) { _, which ->
            prefs.edit().putString("bg_type", "color").putInt("bg_color", cols[which]).apply()
            applyBackground()
        }.show()
    }

    private fun pickFile(mime: String, req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, req)
        } catch (_: Exception) {
            toast("No hay selector de archivos")
        }
    }

    private fun applyBackground() {
        val type = prefs.getString("bg_type", "color")
        val uri = prefs.getString("bg_value", null)?.let { Uri.parse(it) }
        root.setBackgroundColor(prefs.getInt("bg_color", DEFAULT_BG))

        bgImage.setImageDrawable(null)
        bgImage.visibility = View.GONE
        bgVideo.setSource(null, false)
        bgVideo.visibility = View.GONE

        if (uri == null || type == "color") return
        if (type == "video") {
            bgVideo.visibility = View.VISIBLE
            bgVideo.setSource(uri, prefs.getBoolean("muted", false))
        } else {
            loadImage(uri)
        }
    }

    private fun loadImage(uri: Uri) {
        val dm = resources.displayMetrics
        Thread {
            try {
                val src = ImageDecoder.createSource(contentResolver, uri)
                val d = ImageDecoder.decodeDrawable(src) { dec, info, _ ->
                    val w = info.size.width
                    val h = info.size.height
                    val s = maxOf(dm.widthPixels.toFloat() / w, dm.heightPixels.toFloat() / h)
                    if (s < 1f) dec.setTargetSize(maxOf(1, (w * s).toInt()), maxOf(1, (h * s).toInt()))
                }
                runOnUiThread {
                    if (prefs.getString("bg_type", "") != "image" || prefs.getString("bg_value", null) != uri.toString()) return@runOnUiThread
                    bgImage.setImageDrawable(d)
                    bgImage.visibility = View.VISIBLE
                    if (d is AnimatedImageDrawable) {
                        d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                        d.start()
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { toast("No se pudo cargar la imagen") }
            }
        }.start()
    }
}
