package com.winlauncher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_IMAGE = 1
private const val REQ_VIDEO = 2
private const val REQ_SHORTCUT = 3
private const val REQ_ICON = 4
private const val DEFAULT_BG = 0xFF429C92.toInt()

/**
 * Un icono del escritorio.
 * kind 0 = app (pkg + cls), 1 = acceso directo con Intent (data), 2 = acceso directo fijado por una app (pkg + cls = id del shortcut).
 * fx/fy = posición como fracción (0..1) del espacio libre de la página.
 */
class Pin(var kind: Int, val pkg: String, val cls: String) {
    var fx = 0f
    var fy = 0f
    var page = 0
    var label: String? = null
    var data: String? = null
    var base: String? = null   // icono original guardado (accesos directos)
    var custom: String? = null // icono elegido por el usuario (PNG con transparencia, etc.)
}

class AppItem(val label: String, val pkg: String, val cls: String, val icon: Drawable)

class MItem(val label: String, val action: () -> Unit)

fun drawableToBitmap(d: Drawable, size: Int): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    d.setBounds(0, 0, size, size)
    d.draw(c)
    return bmp
}

/** Escritorio: coloca cada hijo según su Pin y detecta el deslizamiento entre páginas. */
class Desktop(ctx: Context) : FrameLayout(ctx) {
    var onSwipe: ((Int) -> Unit)? = null
    var swipeBlocked = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val minSwipe = 72 * ctx.resources.displayMetrics.density
    private var sx = 0f
    private var sy = 0f

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_MOVE && !swipeBlocked) {
            val dx = ev.x - sx
            val dy = ev.y - sy
            if (abs(dx) > slop * 3 && abs(dx) > abs(dy) * 1.5f) return true
        }
        return false
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            sx = ev.x
            sy = ev.y
            swipeBlocked = false
        }
        val r = super.dispatchTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP && !swipeBlocked) {
            val dx = ev.x - sx
            val dy = ev.y - sy
            if (abs(dx) > minSwipe && abs(dx) > abs(dy) * 1.5f) onSwipe?.invoke(if (dx < 0) 1 else -1)
        }
        return r
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val pin = v.tag as? Pin ?: continue
            val w = v.measuredWidth
            val h = v.measuredHeight
            val x = (pin.fx * (width - w)).toInt().coerceAtLeast(0)
            val y = (pin.fy * (height - h)).toInt().coerceAtLeast(0)
            v.layout(x, y, x + w, y + h)
        }
    }
}

/** Puntitos que indican en qué página estás. */
class PageDots(ctx: Context) : View(ctx) {
    private var count = 1
    private var index = 0
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(c: Int, i: Int) {
        count = c
        index = i
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val gap = 14 * d
        val x0 = width / 2f - (count - 1) * gap / 2f
        for (i in 0 until count) {
            p.color = if (i == index) 0xFFFFFFFF.toInt() else 0x66FFFFFF
            cv.drawCircle(x0 + i * gap, height / 2f, if (i == index) 3.5f * d else 3f * d, p)
        }
    }
}

/** Fondo de video con audio, recortado para llenar la pantalla. Se libera por completo al salir del launcher. */
class VideoBackground(ctx: Context) : TextureView(ctx), TextureView.SurfaceTextureListener {
    private var player: MediaPlayer? = null
    private var surface: Surface? = null
    private var uri: Uri? = null
    private var muted = false
    private var vw = 0
    private var vh = 0

    init {
        surfaceTextureListener = this
    }

    fun setSource(u: Uri?, mute: Boolean) {
        release()
        uri = u
        muted = mute
        if (u != null) startPlayback()
    }

    fun setMuted(m: Boolean) {
        muted = m
        val v = if (m) 0f else 1f
        try {
            player?.setVolume(v, v)
        } catch (_: Exception) {
        }
    }

    fun startPlayback() {
        val u = uri ?: return
        val s = surface ?: return
        if (player != null) return
        try {
            val p = MediaPlayer()
            player = p
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            )
            p.setDataSource(context, u)
            p.setSurface(s)
            p.isLooping = true
            val v = if (muted) 0f else 1f
            p.setVolume(v, v)
            p.setOnVideoSizeChangedListener { _, w, h ->
                vw = w
                vh = h
                fit()
            }
            p.setOnPreparedListener { it.start() }
            p.setOnErrorListener { _, _, _ ->
                release()
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            release()
        }
    }

    fun stopPlayback() {
        release()
    }

    private fun release() {
        val p = player
        player = null
        if (p != null) {
            try {
                p.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun fit() {
        if (vw == 0 || vh == 0 || width == 0 || height == 0) return
        val s = maxOf(width.toFloat() / vw, height.toFloat() / vh)
        val m = Matrix()
        m.setScale(vw * s / width, vh * s / height, width / 2f, height / 2f)
        setTransform(m)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        surface = Surface(st)
        startPlayback()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
        fit()
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        release()
        surface?.release()
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
}

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var bgImage: ImageView
    private lateinit var bgVideo: VideoBackground
    private lateinit var column: LinearLayout
    private lateinit var desktop: Desktop
    private lateinit var dots: PageDots

    private val pins = ArrayList<Pin>()
    private var pageCount = 1
    private var currentPage = 0
    private var popup: PopupWindow? = null
    private var dialog: AlertDialog? = null
    private var pendX = 0f
    private var pendY = 0f
    private var iconPin: Pin? = null
    private var winCount = 0
    private var frozen = false
    private var sawBlur = false

    private val pm: PackageManager get() = packageManager

    // ───────────────────────── ciclo de vida ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("wl", MODE_PRIVATE)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        loadPins()
        buildUi()
        applyBackground()
    }

    override fun onStart() {
        super.onStart()
        consumePending()
        refreshDesktop()
        if (frozen) {
            unfreezeBackground()
        } else {
            bgVideo.startPlayback()
            (bgImage.drawable as? AnimatedImageDrawable)?.start()
        }
    }

    /** Cuando un juego (en ventana) toma el foco, el fondo ya está congelado; al volver al launcher se reanuda. */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!frozen) return
        if (!hasFocus) sawBlur = true else if (sawBlur) unfreezeBackground()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && frozen && !sawBlur) unfreezeBackground()
        return super.dispatchTouchEvent(ev)
    }

    override fun onStop() {
        super.onStop()
        bgVideo.stopPlayback()
        (bgImage.drawable as? AnimatedImageDrawable)?.stop()
        popup?.dismiss()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        popup?.dismiss()
        dialog?.dismiss()
    }

    override fun onBackPressed() {
        // Un launcher no se cierra con "atrás"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == REQ_SHORTCUT) {
            handleShortcutResult(data)
            return
        }
        if (requestCode == REQ_ICON) {
            handleIconResult(data)
            return
        }
        val uri = data.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        prefs.edit()
            .putString("bg_type", if (requestCode == REQ_VIDEO) "video" else "image")
            .putString("bg_value", uri.toString())
            .apply()
        applyBackground()
    }

    // ───────────────────────── interfaz ─────────────────────────

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun pressBg(): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(0x33FFFFFF))
        addState(intArrayOf(), ColorDrawable(0))
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(prefs.getInt("bg_color", DEFAULT_BG))

        bgImage = ImageView(this)
        bgImage.scaleType = ImageView.ScaleType.CENTER_CROP
        bgImage.visibility = View.GONE
        root.addView(bgImage, MATCH, MATCH)

        bgVideo = VideoBackground(this)
        bgVideo.visibility = View.GONE
        root.addView(bgVideo, MATCH, MATCH)

        column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL

        desktop = Desktop(this)
        desktop.onSwipe = { delta -> goPage(delta) }
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onLongPress(e: MotionEvent) {
                val x = e.x
                val y = e.y
                val rx = e.rawX
                val ry = e.rawY
                desktop.swipeBlocked = true
                desktop.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showMenu(
                    rx, ry, listOf(
                        MItem("Aplicaciones") { pickToAdd(x, y) },
                        MItem("Accesos directos") { pickShortcut(x, y) },
                        MItem("Fondos") { openBackgroundMenu() },
                        MItem("Nueva página") { addPage() },
                        MItem("Ajustes") { openSettings() }
                    )
                )
            }
        })
        desktop.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            true
        }
        column.addView(desktop, LinearLayout.LayoutParams(MATCH, 0, 1f))

        dots = PageDots(this)
        column.addView(dots, LinearLayout.LayoutParams(MATCH, dp(18)))
        updateDots()

        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        root.setOnApplyWindowInsetsListener { _, ins ->
            column.setPadding(
                ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                ins.systemWindowInsetRight, ins.systemWindowInsetBottom
            )
            ins
        }
        setContentView(root)
    }

    private fun updateDots() {
        dots.set(pageCount, currentPage)
        dots.visibility = if (pageCount > 1) View.VISIBLE else View.GONE
    }

    // ───────────────────────── menú emergente ─────────────────────────

    private fun showMenu(rx: Float, ry: Float, items: List<MItem>) {
        popup?.dismiss()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(6), 0, dp(6))
        box.background = GradientDrawable().apply {
            setColor(0xF2202428.toInt())
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), 0x33FFFFFF)
        }
        val pw = PopupWindow(box, WRAP, WRAP, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        for (item in items) {
            val tv = TextView(this)
            tv.text = item.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 15f
            tv.setPadding(dp(20), dp(12), dp(32), dp(12))
            tv.background = pressBg()
            tv.setOnClickListener {
                pw.dismiss()
                item.action()
            }
            box.addView(tv)
        }
        box.measure(0, 0)
        val dm = resources.displayMetrics
        val x = rx.toInt().coerceIn(0, (dm.widthPixels - box.measuredWidth).coerceAtLeast(0))
        val y = ry.toInt().coerceIn(0, (dm.heightPixels - box.measuredHeight).coerceAtLeast(0))
        pw.showAtLocation(root, Gravity.TOP or Gravity.START, x, y)
        popup = pw
    }

    // ───────────────────────── páginas ─────────────────────────

    private fun goPage(delta: Int) {
        val np = currentPage + delta
        if (np < 0 || np >= pageCount) return
        val w = desktop.width.toFloat()
        desktop.animate().translationX(-delta * w).alpha(0f).setDuration(120).withEndAction {
            currentPage = np
            save()
            refreshDesktop()
            updateDots()
            desktop.translationX = delta * w
            desktop.animate().translationX(0f).alpha(1f).setDuration(120).start()
        }.start()
    }

    private fun addPage() {
        pageCount++
        currentPage = pageCount - 1
        save()
        refreshDesktop()
        updateDots()
        toast("Página $pageCount creada")
    }

    private fun removePage() {
        if (pageCount <= 1) return
        val iter = pins.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            if (p.page == currentPage) {
                deleteIconFiles(p)
                iter.remove()
            } else if (p.page > currentPage) {
                p.page--
            }
        }
        pageCount--
        if (currentPage >= pageCount) currentPage = pageCount - 1
        save()
        refreshDesktop()
        updateDots()
    }

    private fun movePage(pin: Pin, delta: Int) {
        pin.page = (pin.page + delta).coerceIn(0, pageCount - 1)
        save()
        refreshDesktop()
    }

    // ───────────────────────── iconos en el escritorio ─────────────────────────

    private fun loadPins() {
        pins.clear()
        pageCount = prefs.getInt("pages", 1).coerceAtLeast(1)
        currentPage = prefs.getInt("page", 0).coerceIn(0, pageCount - 1)
        try {
            val arr = JSONArray(prefs.getString("apps", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val p = Pin(o.optInt("k", 0), o.getString("p"), o.optString("c", ""))
                p.fx = o.getDouble("x").toFloat()
                p.fy = o.getDouble("y").toFloat()
                p.page = o.optInt("g", 0).coerceIn(0, pageCount - 1)
                p.label = if (o.has("l")) o.getString("l") else null
                p.data = if (o.has("d")) o.getString("d") else null
                p.base = if (o.has("b")) o.getString("b") else null
                p.custom = if (o.has("i")) o.getString("i") else null
                pins.add(p)
            }
        } catch (_: Exception) {
        }
    }

    private fun save() {
        val arr = JSONArray()
        for (p in pins) {
            val o = JSONObject()
                .put("k", p.kind).put("p", p.pkg).put("c", p.cls)
                .put("x", p.fx.toDouble()).put("y", p.fy.toDouble()).put("g", p.page)
            p.label?.let { o.put("l", it) }
            p.data?.let { o.put("d", it) }
            p.base?.let { o.put("b", it) }
            p.custom?.let { o.put("i", it) }
            arr.put(o)
        }
        prefs.edit()
            .putString("apps", arr.toString())
            .putInt("pages", pageCount)
            .putInt("page", currentPage)
            .apply()
    }

    /** Accesos directos fijados por otras apps (p. ej. "Agregar a pantalla de inicio") que llegaron mientras no estábamos abiertos. */
    private fun consumePending() {
        val s = prefs.getString("pending", null) ?: return
        prefs.edit().remove("pending").apply()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val p = Pin(2, o.getString("pkg"), o.getString("id"))
                p.label = o.optString("label", "")
                val ic = o.optString("icon", "")
                p.base = if (ic.isEmpty()) null else ic
                p.page = currentPage
                p.fx = (0.08f + 0.1f * (pins.size % 8)).coerceAtMost(1f)
                p.fy = (0.1f + 0.1f * (pins.size % 6)).coerceAtMost(1f)
                pins.add(p)
            }
            save()
        } catch (_: Exception) {
        }
    }

    private fun labelOf(pin: Pin): CharSequence? {
        if (pin.kind != 0) return pin.label ?: ""
        return try {
            pm.getActivityInfo(ComponentName(pin.pkg, pin.cls), 0).loadLabel(pm)
        } catch (_: Exception) {
            null
        }
    }

    /** Estilo Windows: del icono adaptable solo se usa la capa frontal (sin placa ni máscara), así queda transparente. */
    private fun styled(d: Drawable): Drawable {
        if (prefs.getBoolean("win_icons", true) && d is AdaptiveIconDrawable) {
            val fg = d.foreground
            if (fg != null) return InsetDrawable(fg, -0.25f)
        }
        return d
    }

    private fun iconFor(pin: Pin): Drawable {
        for (f in listOf(pin.custom, pin.base)) {
            if (f != null) {
                val b = BitmapFactory.decodeFile(File(filesDir, f).path)
                if (b != null) return BitmapDrawable(resources, b)
            }
        }
        if (pin.kind == 0) {
            try {
                return styled(pm.getActivityInfo(ComponentName(pin.pkg, pin.cls), 0).loadIcon(pm))
            } catch (_: Exception) {
            }
        }
        return pm.defaultActivityIcon
    }

    private fun refreshDesktop() {
        desktop.removeAllViews()
        var changed = false
        val iter = pins.iterator()
        while (iter.hasNext()) {
            val pin = iter.next()
            if (labelOf(pin) == null) { // la app ya no está instalada
                iter.remove()
                changed = true
            }
        }
        if (changed) save()
        for (pin in pins) {
            if (pin.page != currentPage) continue
            val v = iconView(pin) ?: continue
            desktop.addView(v, FrameLayout.LayoutParams(WRAP, WRAP))
        }
    }

    private fun iconView(pin: Pin): View? {
        val text = labelOf(pin) ?: return null
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(8), dp(10), dp(8))

        val icon = ImageView(this)
        icon.setImageDrawable(iconFor(pin))
        row.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))

        val label = TextView(this)
        label.text = text
        label.setTextColor(Color.WHITE)
        label.textSize = 13f
        label.setTypeface(label.typeface, Typeface.BOLD)
        label.setSingleLine()
        label.ellipsize = TextUtils.TruncateAt.END
        label.maxWidth = dp(130)
        label.setShadowLayer(4f, 0f, 1f, Color.BLACK)
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.leftMargin = dp(8)
        row.addView(label, lp)

        row.tag = pin
        row.setOnTouchListener(IconTouch(pin, row))
        return row
    }

    private fun addPin(pin: Pin, x: Float, y: Float) {
        pin.page = currentPage
        val v = iconView(pin) ?: return
        v.measure(0, 0)
        val w = v.measuredWidth
        val h = v.measuredHeight
        pin.fx = ((x - w / 2f) / (desktop.width - w).coerceAtLeast(1)).coerceIn(0f, 1f)
        pin.fy = ((y - h / 2f) / (desktop.height - h).coerceAtLeast(1)).coerceIn(0f, 1f)
        pins.add(pin)
        desktop.addView(v, FrameLayout.LayoutParams(WRAP, WRAP))
        save()
    }

    private fun deleteIconFiles(pin: Pin) {
        pin.base?.let { File(filesDir, it).delete() }
        pin.custom?.let { File(filesDir, it).delete() }
    }

    private fun removePin(pin: Pin, v: View) {
        pins.remove(pin)
        deleteIconFiles(pin)
        desktop.removeView(v)
        save()
    }

    private fun dragTo(pin: Pin, v: View, left: Float, top: Float) {
        val loc = IntArray(2)
        desktop.getLocationOnScreen(loc)
        pin.fx = ((left - loc[0]) / (desktop.width - v.width).coerceAtLeast(1)).coerceIn(0f, 1f)
        pin.fy = ((top - loc[1]) / (desktop.height - v.height).coerceAtLeast(1)).coerceIn(0f, 1f)
        desktop.requestLayout()
    }

    /** Toque = abrir. Mantener y arrastrar = mover. Mantener y soltar sin mover = menú del icono. */
    private inner class IconTouch(val pin: Pin, val v: View) : View.OnTouchListener {
        private var dragging = false
        private var cancelled = false
        private var moved = false
        private var downX = 0f
        private var downY = 0f
        private var offX = 0f
        private var offY = 0f
        private val slop = ViewConfiguration.get(this@MainActivity).scaledTouchSlop

        private val longPress = Runnable {
            dragging = true
            desktop.swipeBlocked = true
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            v.parent?.requestDisallowInterceptTouchEvent(true)
            v.alpha = 0.7f
        }

        override fun onTouch(view: View, ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    cancelled = false
                    moved = false
                    downX = ev.rawX
                    downY = ev.rawY
                    offX = ev.x
                    offY = ev.y
                    v.setBackgroundColor(0x33FFFFFF)
                    v.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                }
                MotionEvent.ACTION_MOVE -> {
                    val far = abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop
                    if (dragging) {
                        if (far) moved = true
                        dragTo(pin, v, ev.rawX - offX, ev.rawY - offY)
                    } else if (far) {
                        cancelled = true
                        v.removeCallbacks(longPress)
                        v.background = null
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.removeCallbacks(longPress)
                    v.background = null
                    v.alpha = 1f
                    if (dragging) {
                        if (moved) save() else showMenu(ev.rawX, ev.rawY, iconMenu(pin, v))
                    } else if (!cancelled) {
                        open(pin)
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(longPress)
                    v.background = null
                    v.alpha = 1f
                }
            }
            return true
        }
    }

    private fun iconMenu(pin: Pin, v: View): List<MItem> {
        val items = ArrayList<MItem>()
        items.add(MItem("Cambiar icono") {
            iconPin = pin
            pickFile("image/*", REQ_ICON)
        })
        if (pin.custom != null) {
            items.add(MItem("Icono original") {
                pin.custom?.let { File(filesDir, it).delete() }
                pin.custom = null
                save()
                refreshDesktop()
            })
        }
        if (pageCount > 1) {
            if (pin.page < pageCount - 1) items.add(MItem("Mover a la página siguiente") { movePage(pin, 1) })
            if (pin.page > 0) items.add(MItem("Mover a la página anterior") { movePage(pin, -1) })
        }
        if (pin.pkg.isNotEmpty()) {
            val g = isGame(pin.pkg)
            items.add(MItem(if (g) "Quitar marca de juego" else "Marcar como juego") { setGame(pin.pkg, !g) })
        }
        items.add(MItem("Quitar") { removePin(pin, v) })
        return items
    }

    // ───────────────────────── juegos ─────────────────────────

    private fun isGame(pkg: String): Boolean {
        if (pkg.isEmpty()) return false
        if (prefs.getStringSet("g_yes", null)?.contains(pkg) == true) return true
        if (prefs.getStringSet("g_no", null)?.contains(pkg) == true) return false
        return try {
            val ai = pm.getApplicationInfo(pkg, 0)
            ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        } catch (_: Exception) {
            false
        }
    }

    private fun setGame(pkg: String, game: Boolean) {
        val yes = HashSet<String>(prefs.getStringSet("g_yes", null) ?: emptySet<String>())
        val no = HashSet<String>(prefs.getStringSet("g_no", null) ?: emptySet<String>())
        if (game) {
            yes.add(pkg)
            no.remove(pkg)
        } else {
            yes.remove(pkg)
            no.add(pkg)
        }
        prefs.edit().putStringSet("g_yes", yes).putStringSet("g_no", no).apply()
        toast(if (game) "Marcado como juego" else "Ya no se trata como juego")
    }

    /** Deja el fondo animado quieto (video = último cuadro; GIF = cuadro actual) para no gastar recursos mientras juegas. */
    private fun freezeBackground() {
        if (frozen || !prefs.getBoolean("freeze_bg", true)) return
        val type = prefs.getString("bg_type", "color")
        if (type == "video") {
            val bmp = try {
                bgVideo.bitmap
            } catch (_: Exception) {
                null
            }
            if (bmp != null) {
                bgImage.setImageBitmap(bmp)
                bgImage.visibility = View.VISIBLE
            }
            bgVideo.visibility = View.INVISIBLE
            bgVideo.stopPlayback()
            frozen = true
        } else if (type == "image") {
            val d = bgImage.drawable
            if (d is AnimatedImageDrawable) {
                d.stop()
                frozen = true
            }
        }
        sawBlur = false
    }

    private fun unfreezeBackground() {
        if (!frozen) return
        frozen = false
        val type = prefs.getString("bg_type", "color")
        if (type == "video") {
            bgVideo.visibility = View.VISIBLE
            bgVideo.startPlayback()
            bgImage.postDelayed({
                if (!frozen && prefs.getString("bg_type", "color") == "video") {
                    bgImage.setImageDrawable(null)
                    bgImage.visibility = View.GONE
                }
            }, 500)
        } else if (type == "image") {
            (bgImage.drawable as? AnimatedImageDrawable)?.start()
        }
    }

    // ───────────────────────── abrir (en ventana) ─────────────────────────

    private fun windowOptions(game: Boolean): Bundle? {
        val gameWin = game && prefs.getBoolean("game_window", true)
        if (!gameWin && !prefs.getBoolean("windowed", true)) return null
        return try {
            val dm = resources.displayMetrics
            val r: Rect = if (gameWin) {
                // Juegos: ventana casi a pantalla completa
                val w = (dm.widthPixels * 0.98f).toInt()
                val h = (dm.heightPixels * 0.95f).toInt()
                val l = (dm.widthPixels - w) / 2
                val t = (dm.heightPixels - h) / 2
                Rect(l, t, l + w, t + h)
            } else {
                val w = (dm.widthPixels * 0.62f).toInt()
                val h = (dm.heightPixels * 0.72f).toInt()
                val step = dp(36)
                val n = winCount++ % 6
                val l = ((dm.widthPixels - w) / 2 + (n - 3) * step).coerceIn(0, dm.widthPixels - w)
                val t = (dp(40) + n * step).coerceIn(0, dm.heightPixels - h)
                Rect(l, t, l + w, t + h)
            }
            val o = ActivityOptions.makeBasic()
            o.setLaunchBounds(r)
            try {
                // Modo "ventana libre" (5). Solo funciona si el sistema tiene ventanas libres activadas.
                ActivityOptions::class.java
                    .getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                    .invoke(o, 5)
            } catch (_: Throwable) {
            }
            o.toBundle()
        } catch (_: Exception) {
            null
        }
    }

    private fun startIntent(i: Intent, pkg: String) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val game = isGame(pkg)
        try {
            startActivity(i, windowOptions(game))
            if (game) freezeBackground()
        } catch (_: Exception) {
            toast("No se pudo abrir")
        }
    }

    private fun open(pin: Pin) {
        when (pin.kind) {
            0 -> startIntent(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(pin.pkg, pin.cls)),
                pin.pkg
            )
            1 -> {
                val i = try {
                    Intent.parseUri(pin.data ?: "", 0)
                } catch (_: Exception) {
                    null
                }
                if (i == null) toast("Acceso directo inválido") else startIntent(i, pin.pkg)
            }
            else -> {
                val game = isGame(pin.pkg)
                try {
                    val la = getSystemService(LauncherApps::class.java)
                    la.startShortcut(pin.pkg, pin.cls, null, windowOptions(game), Process.myUserHandle())
                    if (game) freezeBackground()
                } catch (_: Exception) {
                    toast("No se pudo abrir (el launcher debe ser el predeterminado)")
                }
            }
        }
    }

    // ───────────────────────── lista de apps / accesos directos ─────────────────────────

    private fun loadApps(query: Intent, cb: (List<AppItem>) -> Unit) {
        Thread {
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    AppItem(ri.loadLabel(pm).toString(), ri.activityInfo.packageName, ri.activityInfo.name, ri.loadIcon(pm))
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread { cb(list) }
        }.start()
    }

    private fun pickToAdd(x: Float, y: Float) {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        loadApps(q) { apps ->
            showAppList(apps) { app -> addPin(Pin(0, app.pkg, app.cls), x, y) }
        }
    }

    private fun pickShortcut(x: Float, y: Float) {
        pendX = x
        pendY = y
        loadApps(Intent(Intent.ACTION_CREATE_SHORTCUT)) { apps ->
            if (apps.isEmpty()) {
                toast("Ninguna app ofrece accesos directos")
            } else {
                showAppList(apps) { a ->
                    try {
                        startActivityForResult(
                            Intent(Intent.ACTION_CREATE_SHORTCUT).setComponent(ComponentName(a.pkg, a.cls)),
                            REQ_SHORTCUT
                        )
                    } catch (_: Exception) {
                        toast("No se pudo abrir")
                    }
                }
            }
        }
    }

    private fun saveBitmap(src: Bitmap): String? {
        return try {
            val m = maxOf(src.width, src.height)
            val bmp = if (m > 192) {
                val s = 192f / m
                Bitmap.createScaledBitmap(src, maxOf(1, (src.width * s).toInt()), maxOf(1, (src.height * s).toInt()), true)
            } else src
            val name = "ic_" + System.nanoTime() + ".png"
            FileOutputStream(File(filesDir, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            name
        } catch (_: Exception) {
            null
        }
    }

    private fun handleShortcutResult(data: Intent) {
        val si = data.getParcelableExtra<Intent>(Intent.EXTRA_SHORTCUT_INTENT)
        if (si == null) {
            toast("No se pudo crear ese acceso directo")
            return
        }
        val name = data.getStringExtra(Intent.EXTRA_SHORTCUT_NAME) ?: "Acceso directo"
        var bmp = data.getParcelableExtra<Bitmap>(Intent.EXTRA_SHORTCUT_ICON)
        if (bmp == null) {
            val res = data.getParcelableExtra<Intent.ShortcutIconResource>(Intent.EXTRA_SHORTCUT_ICON_RESOURCE)
            if (res != null) {
                try {
                    val r = pm.getResourcesForApplication(res.packageName)
                    val id = r.getIdentifier(res.resourceName, null, null)
                    bmp = drawableToBitmap(r.getDrawable(id, null), 192)
                } catch (_: Exception) {
                }
            }
        }
        val pin = Pin(1, si.component?.packageName ?: "", "")
        pin.label = name
        pin.data = si.toUri(0)
        if (bmp != null) pin.base = saveBitmap(bmp)
        addPin(pin, pendX, pendY)
    }

    private fun importIcon(uri: Uri): String? {
        return try {
            val src = ImageDecoder.createSource(contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val m = maxOf(info.size.width, info.size.height)
                if (m > 192) {
                    val s = 192f / m
                    dec.setTargetSize(maxOf(1, (info.size.width * s).toInt()), maxOf(1, (info.size.height * s).toInt()))
                }
            }
            saveBitmap(bmp)
        } catch (_: Exception) {
            null
        }
    }

    private fun handleIconResult(data: Intent) {
        val uri = data.data ?: return
        val pin = iconPin ?: return
        val name = importIcon(uri)
        if (name == null) {
            toast("No se pudo usar esa imagen")
            return
        }
        pin.custom?.let { File(filesDir, it).delete() }
        pin.custom = name
        save()
        refreshDesktop()
    }

    private fun showAppList(apps: List<AppItem>, onPick: (AppItem) -> Unit) {
        if (isFinishing || isDestroyed) return
        dialog?.dismiss()
        var shown: List<AppItem> = apps

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(12), dp(12), dp(8))

        val search = EditText(this)
        search.hint = "Buscar"
        search.setSingleLine()
        search.setTextColor(Color.WHITE)
        search.setHintTextColor(0x88FFFFFF.toInt())

        val list = ListView(this)
        list.divider = null

        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(position: Int): Any = shown[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val row: LinearLayout = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                    addView(ImageView(context), LinearLayout.LayoutParams(dp(36), dp(36)))
                    val tv = TextView(context)
                    tv.setTextColor(Color.WHITE)
                    tv.textSize = 16f
                    tv.setSingleLine()
                    tv.ellipsize = TextUtils.TruncateAt.END
                    val lp = LinearLayout.LayoutParams(WRAP, WRAP)
                    lp.leftMargin = dp(14)
                    addView(tv, lp)
                }
                val a = shown[position]
                (row.getChildAt(0) as ImageView).setImageDrawable(a.icon)
                (row.getChildAt(1) as TextView).text = a.label
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val a = shown[pos]
            dialog?.dismiss()
            onPick(a)
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString().trim().lowercase()
                shown = if (q.isEmpty()) apps else apps.filter { it.label.lowercase().contains(q) }
                adapter.notifyDataSetChanged()
            }
        })

        box.addView(search, LinearLayout.LayoutParams(MATCH, WRAP))
        val dm = resources.displayMetrics
        box.addView(list, LinearLayout.LayoutParams(MATCH, (dm.heightPixels * 0.6f).toInt()))

        val d = AlertDialog.Builder(this).setView(box).create()
        glass(d)
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        d.show()
        d.window?.setLayout(minOf((dm.widthPixels * 0.92f).toInt(), dp(520)), WRAP)
        dialog = d
    }

    /** Panel transparente (cristal oscuro) para todos los cuadros de diálogo. */
    private fun glass(d: AlertDialog) {
        d.window?.setBackgroundDrawable(GradientDrawable().apply {
            setColor(0xB3101418.toInt())
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), 0x33FFFFFF)
        })
        d.window?.setDimAmount(0.12f)
    }

    // ───────────────────────── ajustes ─────────────────────────

    private fun openSettings() {
        val win = prefs.getBoolean("windowed", true)
        val gameWin = prefs.getBoolean("game_window", true)
        val freeze = prefs.getBoolean("freeze_bg", true)
        val style = prefs.getBoolean("win_icons", true)
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add("Abrir apps en ventana: " + (if (win) "sí" else "no"))
        acts.add { prefs.edit().putBoolean("windowed", !win).apply() }
        labels.add("Juegos en ventana casi completa: " + (if (gameWin) "sí" else "no"))
        acts.add { prefs.edit().putBoolean("game_window", !gameWin).apply() }
        labels.add("Fondo estático al abrir un juego: " + (if (freeze) "sí" else "no"))
        acts.add { prefs.edit().putBoolean("freeze_bg", !freeze).apply() }
        labels.add("Iconos: " + (if (style) "estilo Windows (transparentes)" else "originales de Android"))
        acts.add {
            prefs.edit().putBoolean("win_icons", !style).apply()
            refreshDesktop()
        }
        if (pageCount > 1) {
            labels.add("Quitar esta página")
            acts.add { removePage() }
        }
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Ajustes").setItems(labels.toTypedArray()) { _, which ->
            acts[which]()
        }.create()
        glass(d)
        d.show()
        dialog = d
    }

    // ───────────────────────── fondos ─────────────────────────

    private fun openBackgroundMenu() {
        val muted = prefs.getBoolean("muted", false)
        val items = arrayOf(
            "Color sólido",
            "Imagen o GIF animado",
            "Video (con audio)",
            if (muted) "Sonido del video: apagado" else "Sonido del video: encendido"
        )
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Fondos").setItems(items) { _, which ->
            when (which) {
                0 -> pickColor()
                1 -> pickFile("image/*", REQ_IMAGE)
                2 -> pickFile("video/*", REQ_VIDEO)
                3 -> {
                    prefs.edit().putBoolean("muted", !muted).apply()
                    bgVideo.setMuted(!muted)
                }
            }
        }.create()
        glass(d)
        d.show()
        dialog = d
    }

    private fun pickColor() {
        val names = arrayOf("Verde azulado", "Azul", "Negro", "Gris oscuro", "Morado", "Vino")
        val cols = intArrayOf(
            0xFF429C92.toInt(), 0xFF0F6CBD.toInt(), 0xFF000000.toInt(),
            0xFF2B2B2B.toInt(), 0xFF5B3A8C.toInt(), 0xFF7A1F3D.toInt()
        )
        dialog?.dismiss()
        val d = AlertDialog.Builder(this).setTitle("Color").setItems(names) { _, which ->
            prefs.edit().putString("bg_type", "color").putInt("bg_color", cols[which]).apply()
            applyBackground()
        }.create()
        glass(d)
        d.show()
        dialog = d
    }

    private fun pickFile(mime: String, req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, req)
        } catch (_: Exception) {
            toast("No hay selector de archivos")
        }
    }

    private fun applyBackground() {
        frozen = false
        val type = prefs.getString("bg_type", "color")
        val uri = prefs.getString("bg_value", null)?.let { Uri.parse(it) }
        root.setBackgroundColor(prefs.getInt("bg_color", DEFAULT_BG))

        bgImage.setImageDrawable(null)
        bgImage.visibility = View.GONE
        bgVideo.setSource(null, false)
        bgVideo.visibility = View.GONE

        if (uri == null || type == "color") return
        if (type == "video") {
            bgVideo.visibility = View.VISIBLE
            bgVideo.setSource(uri, prefs.getBoolean("muted", false))
        } else {
            loadImage(uri)
        }
    }

    private fun loadImage(uri: Uri) {
        val dm = resources.displayMetrics
        Thread {
            try {
                val src = ImageDecoder.createSource(contentResolver, uri)
                val d = ImageDecoder.decodeDrawable(src) { dec, info, _ ->
                    val w = info.size.width
                    val h = info.size.height
                    val s = maxOf(dm.widthPixels.toFloat() / w, dm.heightPixels.toFloat() / h)
                    if (s < 1f) dec.setTargetSize(maxOf(1, (w * s).toInt()), maxOf(1, (h * s).toInt()))
                }
                runOnUiThread {
                    if (prefs.getString("bg_type", "") != "image" || prefs.getString("bg_value", null) != uri.toString()) return@runOnUiThread
                    bgImage.setImageDrawable(d)
                    bgImage.visibility = View.VISIBLE
                    if (d is AnimatedImageDrawable) {
                        d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                        d.start()
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { toast("No se pudo cargar la imagen") }
            }
        }.start()
    }
}
