package com.winlauncher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import kotlin.math.abs

/** Anfitrión de widgets: crea nuestra vista especial para poder mover/quitar el widget con pulsación larga. */
class WinHost(ctx: Context) : AppWidgetHost(ctx, 1024) {
    override fun onCreateView(context: Context, appWidgetId: Int, appWidget: AppWidgetProviderInfo?): AppWidgetHostView {
        return WidgetView(context)
    }
}

class WidgetView(ctx: Context) : AppWidgetHostView(ctx) {
    /** (x local, y local, x en pantalla, y en pantalla) */
    var onLongPress: ((Float, Float, Float, Float) -> Unit)? = null
    var onDragEvent: ((MotionEvent) -> Unit)? = null

    private var longFired = false
    private var claimed = false
    private var dx = 0f
    private var dy = 0f
    private var lx = 0f
    private var ly = 0f
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    private val longRun = Runnable {
        longFired = true
        claimed = false
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        parent?.requestDisallowInterceptTouchEvent(true)
        onLongPress?.invoke(lx, ly, dx, dy)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        val a = ev.actionMasked
        if (a == MotionEvent.ACTION_DOWN) {
            longFired = false
            claimed = false
            dx = ev.rawX
            dy = ev.rawY
            lx = ev.x
            ly = ev.y
            postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
        } else if (a == MotionEvent.ACTION_MOVE) {
            if (!longFired && (abs(ev.rawX - dx) > slop || abs(ev.rawY - dy) > slop)) removeCallbacks(longRun)
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            removeCallbacks(longRun)
        }
        if (longFired) {
            if (!claimed) {
                claimed = true
                onDragEvent?.invoke(ev)
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                longFired = false
                claimed = false
            }
            return true
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (longFired) {
            onDragEvent?.invoke(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                longFired = false
                claimed = false
            }
            return true
        }
        return super.onTouchEvent(ev)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val d = resources.displayMetrics.density
        val wd = (w / d).toInt()
        val hd = (h / d).toInt()
        try {
            updateAppWidgetSize(null, wd, hd, wd, hd)
        } catch (_: Exception) {
        }
    }
}
