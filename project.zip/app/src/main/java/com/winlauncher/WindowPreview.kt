package com.winlauncher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * Miniatura de la pantalla (con marco, como una tablet) que muestra dónde y de qué tamaño se abrirían
 * las ventanas de juegos (verde) y apps (naranja). Al mover los controles las ventanas se deslizan suave.
 */
class WindowPreview(ctx: Context, private val sw: Int, private val sh: Int, private val animated: Boolean = true) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val inner = RectF()

    // [ancho, alto, x, y] como fracción 0..1
    private val curG = floatArrayOf(0.98f, 0.95f, 0.5f, 0.5f)
    private val curA = floatArrayOf(0.62f, 0.72f, 0.5f, 0.5f)
    private val fromG = FloatArray(4)
    private val fromA = FloatArray(4)
    private val dstG = FloatArray(4)
    private val dstA = FloatArray(4)
    private var anim: ValueAnimator? = null

    fun set(g: FloatArray, a: FloatArray) {
        anim?.cancel()
        g.copyInto(dstG)
        a.copyInto(dstA)
        if (!animated || width == 0) {
            dstG.copyInto(curG)
            dstA.copyInto(curA)
            invalidate()
            return
        }
        curG.copyInto(fromG)
        curA.copyInto(fromA)
        val va = ValueAnimator.ofFloat(0f, 1f)
        va.duration = 160
        va.interpolator = DecelerateInterpolator()
        va.addUpdateListener { v ->
            val t = v.animatedValue as Float
            for (i in 0 until 4) {
                curG[i] = fromG[i] + (dstG[i] - fromG[i]) * t
                curA[i] = fromA[i] + (dstA[i] - fromA[i]) * t
            }
            invalidate()
        }
        anim = va
        va.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val maxW = View.MeasureSpec.getSize(widthMeasureSpec)
        val aspect = sw.toFloat() / sh
        var h = (190 * d).toInt()
        if (maxW > 0) h = minOf(h, (maxW / aspect).toInt())
        setMeasuredDimension((h * aspect).toInt(), h)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bezel = 5 * d
        // marco del dispositivo
        p.style = Paint.Style.FILL
        p.color = 0xFF14171B.toInt()
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, 10 * d, 10 * d, p)
        // pantalla
        inner.set(bezel, bezel, w - bezel, h - bezel)
        p.color = 0xFF2E6F68.toInt()
        c.drawRoundRect(inner, 5 * d, 5 * d, p)
        c.save()
        c.clipRect(inner)
        drawWin(c, curA, 0xFFFFA64D.toInt(), "App")
        drawWin(c, curG, 0xFF5CE08A.toInt(), "Juego")
        c.restore()
    }

    private fun drawWin(c: Canvas, f: FloatArray, color: Int, label: String) {
        val iw = inner.width()
        val ih = inner.height()
        val ww = f[0] * iw
        val wh = f[1] * ih
        val l = inner.left + (iw - ww) * f[2]
        val t = inner.top + (ih - wh) * f[3]
        rect.set(l, t, l + ww, t + wh)
        val rgb = color and 0x00FFFFFF
        p.style = Paint.Style.FILL
        p.color = rgb or 0x55000000
        c.drawRect(rect, p)
        val bar = minOf(wh, 7 * d)
        p.color = rgb or 0xAA000000.toInt()
        c.drawRect(l, t, l + ww, t + bar, p)
        // botones de la ventana (puntitos)
        p.color = Color.WHITE
        val cy = t + bar / 2f
        for (i in 0 until 3) {
            val cx = l + ww - (4 + i * 5) * d
            if (cx > l + 20 * d) c.drawCircle(cx, cy, 1.3f * d, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * d
        p.color = color
        c.drawRect(rect, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.textSize = 10 * d
        c.drawText(label, l + 4 * d, t + bar + 11 * d, p)
    }
}
