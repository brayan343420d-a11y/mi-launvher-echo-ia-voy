package com.winlauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Recibe los accesos directos que otras apps piden fijar (p. ej. Chrome > "Agregar a pantalla de inicio").
 * Solo funciona cuando WinLauncher es el launcher predeterminado.
 */
class PinShortcutActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val la = getSystemService(LauncherApps::class.java)
            val req = la.getPinItemRequest(intent)
            if (req != null && req.requestType == LauncherApps.PinItemRequest.REQUEST_TYPE_SHORTCUT) {
                val info = req.shortcutInfo
                if (info != null && req.accept()) {
                    var iconName = ""
                    try {
                        val d = la.getShortcutIconDrawable(info, resources.displayMetrics.densityDpi)
                        if (d != null) {
                            val bmp = drawableToBitmap(d, 192)
                            iconName = "sc_" + System.nanoTime() + ".png"
                            FileOutputStream(File(filesDir, iconName)).use {
                                bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
                            }
                        }
                    } catch (_: Exception) {
                    }
                    val prefs = getSharedPreferences("wl", MODE_PRIVATE)
                    val arr = JSONArray(prefs.getString("pending", "[]"))
                    arr.put(
                        JSONObject()
                            .put("pkg", info.getPackage())
                            .put("id", info.id)
                            .put("label", (info.shortLabel ?: "").toString())
                            .put("icon", iconName)
                    )
                    prefs.edit().putString("pending", arr.toString()).apply()
                }
            }
        } catch (_: Exception) {
        }
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
        finish()
    }
}
