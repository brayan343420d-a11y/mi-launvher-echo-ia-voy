package com.winlauncher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import rikka.shizuku.Shizuku

/**
 * Monitor de rendimiento de OTRA app, estilo MSI Afterburner: FPS, CPU, GPU, RAM, temperatura y batería.
 * Android no deja medir esto sin permisos especiales, así que usa Shizuku (permiso tipo "shell/adb") para leer
 * `dumpsys SurfaceFlinger --latency` (FPS) y archivos de /proc y /sys (CPU, GPU, temperatura).
 * Se dibuja en una ventana flotante pegada a una esquina de la VENTANA del juego. Solo corre mientras el juego está abierto.
 */
object FpsMonitor {
    const val F_FPS = 1
    const val F_CPU = 2
    const val F_GPU = 4
    const val F_RAM = 8
    const val F_TEMP = 16
    const val F_BAT = 32
    const val DEFAULT_ITEMS = F_FPS or F_CPU or F_GPU or F_RAM or F_TEMP

    private const val LABEL = 0xFF4FC3FF.toInt()
    private const val DIM = 0xFFB0BEC5.toInt()

    private val ui = Handler(Looper.getMainLooper())
    private var token = 0
    private var view: TextView? = null
    private var wm: WindowManager? = null
    private var corner = 0
    private var density = 1f

    /** Rectángulo de la ventana del juego en coordenadas de pantalla (null = pantalla completa). */
    @Volatile
    private var bounds: Rect? = null

    fun shizukuRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) {
        false
    }

    fun shizukuGranted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    fun requestShizuku(code: Int) {
        try {
            Shizuku.requestPermission(code)
        } catch (_: Throwable) {
        }
    }

    fun canOverlay(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun ready(ctx: Context): Boolean = shizukuRunning() && shizukuGranted() && canOverlay(ctx)

    /** Debe llamarse desde el hilo principal. corner: 0 arriba-izq, 1 arriba-der, 2 abajo-izq, 3 abajo-der. */
    fun start(ctx: Context, pkg: String, corner: Int, items: Int, launchBounds: Rect?) {
        stop()
        if (!ready(ctx)) return
        val app = ctx.applicationContext
        this.corner = corner
        this.bounds = if (launchBounds != null) Rect(launchBounds) else null
        showOverlay(app)
        val my = token
        val t = Thread { loop(app, pkg, items, my) }
        t.isDaemon = true
        t.priority = Thread.MIN_PRIORITY
        t.start()
    }

    fun stop() {
        token++
        val v = view
        view = null
        if (v != null) {
            try {
                wm?.removeView(v)
            } catch (_: Exception) {
            }
        }
    }

    /** El launcher cambió el tamaño/posición de la ventana (por ejemplo al girar la tablet): recolocar el contador. */
    fun updateBounds(r: Rect) {
        bounds = Rect(r)
        ui.post { place() }
    }

    // ───────────── ventana flotante ─────────────

    private fun showOverlay(app: Context) {
        val w = app.getSystemService(WindowManager::class.java)
        density = app.resources.displayMetrics.density
        val d = density
        val tv = TextView(app)
        tv.text = "FPS --"
        tv.setTextColor(Color.WHITE)
        tv.textSize = 12f
        tv.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        tv.setShadowLayer(3f, 0f, 1f, Color.BLACK)
        tv.setLineSpacing(0f, 1.05f)
        tv.setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
        val bg = GradientDrawable()
        bg.setColor(0x33000000)
        bg.cornerRadius = 6 * d
        tv.background = bg
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        try {
            w.addView(tv, lp)
            view = tv
            wm = w
            place()
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun screenSize(w: WindowManager): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = w.maximumWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        w.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    /** Pega el contador a la esquina elegida de la ventana del juego. */
    private fun place() {
        val v = view ?: return
        val w = wm ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        v.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val vw = v.measuredWidth
        val vh = v.measuredHeight
        val sz = screenSize(w)
        val b = bounds ?: Rect(0, 0, sz.first, sz.second)
        val m = (8 * density).toInt()
        val top = (14 * density).toInt()
        val x = if (corner == 1 || corner == 3) b.right - vw - m else b.left + m
        val y = if (corner == 2 || corner == 3) b.bottom - vh - m else b.top + top
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x.coerceAtLeast(0)
        lp.y = y.coerceAtLeast(0)
        try {
            w.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
    }

    // ───────────── bucle de medición ─────────────

    private class Extra(val cpuLine: String?, val gpu: Int?, val cpuTemp: Float?)

    private fun loop(app: Context, pkg: String, items: Int, my: Int) {
        var layer: String? = null
        var gone = 0
        var tick = 0
        var prevTotal = 0L
        var prevIdle = 0L
        val probe = probe()
        val gpuPath = probe.first
        val tempPath = probe.second
        try {
            Thread.sleep(1500)
        } catch (_: InterruptedException) {
            return
        }
        while (token == my) {
            // ¿sigue abierto el juego? y ¿cuál es su capa de dibujo?
            if (layer == null || tick % 4 == 0) {
                val cands = listLayers(pkg)
                if (cands != null) {
                    if (cands.isEmpty()) gone++ else gone = 0
                    if (gone >= 3 && tick >= 12) {
                        ui.post { if (token == my) stop() }
                        return
                    }
                    if (layer == null && cands.isNotEmpty()) layer = pickLayer(cands)
                }
            }
            var fps: Float? = null
            val l = layer
            if (l != null && (items and F_FPS) != 0) {
                fps = measure(l)
                if (fps == null) layer = null
            }

            val x = readExtra(gpuPath, tempPath)
            var cpu: Int? = null
            val cl = x.cpuLine
            if (cl != null) {
                val p = cl.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                if (p.size >= 5) {
                    val total = p.take(8).sum()
                    val idle = p[3] + p[4]
                    if (prevTotal != 0L && total > prevTotal) {
                        val busy = (total - prevTotal) - (idle - prevIdle)
                        cpu = (100L * busy / (total - prevTotal)).toInt().coerceIn(0, 100)
                    }
                    prevTotal = total
                    prevIdle = idle
                }
            }

            val text = render(app, items, fps, cpu, x.cpuTemp, x.gpu)
            ui.post {
                if (token == my) {
                    view?.text = text
                    place()
                }
            }
            // seguir la ventana si el usuario la movió o cambió de tamaño
            if (tick % 3 == 2) {
                val b = windowBounds(pkg)
                if (b != null) bounds = b
            }
            tick++
            try {
                Thread.sleep(1000)
            } catch (_: InterruptedException) {
                return
            }
        }
    }

    // ───────────── dibujo del texto (estilo Afterburner) ─────────────

    private fun line(sb: SpannableStringBuilder, label: String, value: String, unit: String, valueColor: Int, extra: String? = null) {
        if (sb.isNotEmpty()) sb.append('\n')
        val s0 = sb.length
        sb.append(label.padEnd(4)).append(' ')
        sb.setSpan(ForegroundColorSpan(LABEL), s0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val v0 = sb.length
        sb.append(value)
        sb.setSpan(ForegroundColorSpan(valueColor), v0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (unit.isNotEmpty()) {
            val u0 = sb.length
            sb.append(unit)
            sb.setSpan(ForegroundColorSpan(DIM), u0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(RelativeSizeSpan(0.8f), u0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (extra != null) {
            val e0 = sb.length
            sb.append(' ').append(extra)
            sb.setSpan(ForegroundColorSpan(DIM), e0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(RelativeSizeSpan(0.8f), e0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    private fun render(ctx: Context, items: Int, fps: Float?, cpu: Int?, cpuTemp: Float?, gpu: Int?): CharSequence {
        val sb = SpannableStringBuilder()
        if ((items and F_FPS) != 0) {
            val n = if (fps != null) Math.round(fps) else -1
            val color = when {
                n < 0 -> Color.WHITE
                n >= 55 -> 0xFF7CFF7C.toInt()
                n >= 30 -> 0xFFFFD54F.toInt()
                else -> 0xFFFF6E6E.toInt()
            }
            line(sb, "FPS", if (n < 0) "--" else n.toString(), "", color)
        }
        if ((items and F_CPU) != 0) {
            val extra = if (cpuTemp != null) cpuTemp.toInt().toString() + "°C" else null
            line(sb, "CPU", cpu?.toString() ?: "--", "%", Color.WHITE, extra)
        }
        if ((items and F_GPU) != 0) {
            line(sb, "GPU", gpu?.toString() ?: "--", if (gpu != null) "%" else "", Color.WHITE)
        }
        if ((items and F_RAM) != 0) {
            try {
                val mi = ActivityManager.MemoryInfo()
                ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
                val gb = 1024.0 * 1024.0 * 1024.0
                val used = (mi.totalMem - mi.availMem) / gb
                val total = mi.totalMem / gb
                line(sb, "RAM", String.format("%.1f/%.1f", used, total), " GB", Color.WHITE)
            } catch (_: Exception) {
            }
        }
        if ((items and (F_TEMP or F_BAT)) != 0) {
            val bi = try {
                ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            } catch (_: Exception) {
                null
            }
            if (bi != null) {
                if ((items and F_TEMP) != 0) {
                    val t = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
                    if (t != Int.MIN_VALUE) line(sb, "TEMP", String.format("%.0f", t / 10f), "°C", Color.WHITE)
                }
                if ((items and F_BAT) != 0) {
                    val lv = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                    if (lv >= 0 && sc > 0) line(sb, "BAT", (lv * 100 / sc).toString(), "%", Color.WHITE)
                }
            }
        }
        return sb
    }

    // ───────────── shell por Shizuku ─────────────

    private val newProcess by lazy {
        try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            m
        } catch (_: Throwable) {
            null
        }
    }

    /** Ejecuta un comando con permisos de shell (Shizuku). Devuelve su salida, o null si no se pudo ejecutar. */
    fun sh(cmd: String): String? {
        return try {
            val m = newProcess ?: return null
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            try {
                p.waitFor()
            } catch (_: Exception) {
            }
            out
        } catch (_: Throwable) {
            null
        }
    }

    private fun quote(s: String): String =
        "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("$", "\\$").replace("`", "\\`") + "\""

    /** Capas de SurfaceFlinger que pertenecen a esa app (null = no se pudo consultar). Vacío = el juego ya no tiene ventana. */
    fun listLayers(pkg: String): List<String>? {
        val list = sh("dumpsys SurfaceFlinger --list") ?: return null
        return list.lines()
            .map { it.trim() }
            .filter { it.contains(pkg) && !it.startsWith("Background for") && !it.startsWith("Bounds for") && !it.startsWith("Task=") }
    }

    /** Elige la capa que de verdad dibuja el juego (la que más FPS reporta entre las candidatas). */
    private fun pickLayer(cands: List<String>): String? {
        val ordered = cands.sortedBy {
            if (it.contains("SurfaceView") && it.contains("BLAST")) 0 else if (it.contains("SurfaceView")) 1 else 2
        }.take(6)
        var best: String? = null
        var bestFps = -1f
        for (c in ordered) {
            val f = measure(c) ?: continue
            if (f > bestFps) {
                bestFps = f
                best = c
            }
        }
        return best
    }

    private fun measure(layer: String): Float? {
        val out = sh("dumpsys SurfaceFlinger --latency " + quote(layer)) ?: return null
        val ts = ArrayList<Long>()
        val lines = out.lines()
        for (i in 1 until lines.size) {
            val parts = lines[i].trim().split(Regex("\\s+"))
            if (parts.size < 3) continue
            val t = parts[1].toLongOrNull() ?: continue
            if (t > 0L && t != Long.MAX_VALUE) ts.add(t)
        }
        if (ts.size < 2) return null
        ts.sort()
        val last = ts[ts.size - 1]
        if (System.nanoTime() - last > 2_000_000_000L) return 0f // capa parada
        val from = last - 1_000_000_000L
        val win = ts.filter { it >= from }
        if (win.size < 2) return 0f
        val span = (win[win.size - 1] - win[0]).toDouble()
        if (span <= 0.0) return 0f
        return ((win.size - 1) * 1_000_000_000.0 / span).toFloat()
    }

    // ───────────── GPU, CPU y temperatura ─────────────

    /** Busca (una sola vez) dónde da este equipo el uso de GPU y la temperatura de CPU. */
    private fun probe(): Pair<String?, String?> {
        val script =
            "for f in /sys/kernel/ged/hal/gpu_utilization /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage " +
                "/sys/class/kgsl/kgsl-3d0/gpubusy /sys/class/misc/mali0/device/utilisation " +
                "/sys/devices/platform/*mali*/utilization /sys/devices/platform/*mali*/utilisation; do " +
                "if [ -r \"\$f\" ]; then echo \"G:\$f\"; break; fi; done; " +
                "for z in /sys/class/thermal/thermal_zone*; do t=\$(cat \"\$z/type\" 2>/dev/null); " +
                "case \"\$t\" in *cpu*|*CPU*|*soc*|*SOC*|*big*|*tsens*) echo \"T:\$z/temp\"; break;; esac; done"
        val out = sh(script) ?: return Pair(null, null)
        var g: String? = null
        var t: String? = null
        for (raw in out.lines()) {
            val ln = raw.trim()
            if (ln.startsWith("G:")) g = ln.substring(2)
            if (ln.startsWith("T:")) t = ln.substring(2)
        }
        return Pair(g, t)
    }

    private fun readExtra(gpuPath: String?, tempPath: String?): Extra {
        val cmd = "head -n 1 /proc/stat; echo '#'; " +
            (if (gpuPath != null) "cat " + quote(gpuPath) + " 2>/dev/null; " else "") +
            "echo '#'; " +
            (if (tempPath != null) "cat " + quote(tempPath) + " 2>/dev/null; " else "")
        val out = sh(cmd) ?: return Extra(null, null, null)
        val lines = out.lines().map { it.trim() }
        val i1 = lines.indexOf("#")
        val i2 = lines.lastIndexOf("#")
        val cpuLine = lines.firstOrNull { it.startsWith("cpu ") }

        var gpu: Int? = null
        if (gpuPath != null && i1 >= 0 && i2 > i1) {
            val nums = lines.subList(i1 + 1, i2).joinToString(" ")
                .split(Regex("[^0-9]+")).filter { it.isNotEmpty() }.mapNotNull { it.toLongOrNull() }
            if (nums.isNotEmpty()) {
                val g = if (gpuPath.endsWith("gpubusy") && nums.size >= 2 && nums[1] > 0L) {
                    (nums[0] * 100L / nums[1]).toInt()
                } else {
                    nums[0].toInt()
                }
                gpu = g.coerceIn(0, 100)
            }
        }

        var cpuTemp: Float? = null
        if (tempPath != null && i2 >= 0) {
            val raw = lines.drop(i2 + 1).firstOrNull { it.isNotEmpty() }?.toLongOrNull()
            if (raw != null) {
                cpuTemp = when {
                    raw >= 1000L -> raw / 1000f
                    raw >= 150L -> raw / 10f
                    else -> raw.toFloat()
                }
            }
        }
        return Extra(cpuLine, gpu, cpuTemp)
    }

    // ───────────── ventana del juego ─────────────

    /** Rectángulo actual de la ventana de esa app (lo lee de `dumpsys window`). null si no se pudo. */
    fun windowBounds(pkg: String): Rect? {
        val out = sh("dumpsys window windows | grep -F -A16 " + quote(" u0 $pkg/")) ?: return null
        val re = Regex("""(?:^|\s)(?:mFrame|frame)=\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]""")
        val m = re.find(out) ?: return null
        val r = Rect(
            m.groupValues[1].toInt(), m.groupValues[2].toInt(),
            m.groupValues[3].toInt(), m.groupValues[4].toInt()
        )
        return if (r.width() > 0 && r.height() > 0) r else null
    }

    /** Número de la tarea de esa app (null = no se encontró). Prueba varias fuentes porque cambian según la versión de Android. */
    private fun findTaskId(pkg: String): String? {
        val re = Regex("""Task(?:Record)?\{[0-9a-fA-F]+ #(\d+)""")
        val pk = quote("$pkg ")
        val cmds = arrayOf(
            "dumpsys activity activities | grep -E \"Task(Record)?\\{\" | grep -F $pk",
            "dumpsys activity recents | grep -E \"Task(Record)?\\{\" | grep -F $pk"
        )
        for (c in cmds) {
            val out = sh(c) ?: continue
            val id = re.find(out)?.groupValues?.get(1)
            if (id != null) return id
        }
        val st = sh("am stack list 2>/dev/null; cmd activity stack list 2>/dev/null") ?: return null
        return Regex("""taskId=(\d+): """ + Regex.escape(pkg) + "/").find(st)?.groupValues?.get(1)
    }

    /**
     * Pide al sistema (con permisos de shell) que la tarea de esa app tenga exactamente ese rectángulo.
     * forceResizable: antes la marca como redimensionable (para juegos que dicen que no lo son).
     * Devuelve la salida del comando, o null si no se encontró la tarea.
     */
    fun resizeTask(pkg: String, r: Rect, forceResizable: Boolean = false): String? {
        val id = findTaskId(pkg) ?: return null
        val b = r.left.toString() + "," + r.top + "," + r.right + "," + r.bottom
        val pre = if (forceResizable) "am task resizeable $id 2 2>&1; " else ""
        return sh(pre + "am task resize $id $b 2>&1 || cmd activity task resize $id $b 2>&1")
    }

    // ───────────── diagnóstico ─────────────

    /** Informe en texto de qué funciona y qué no (Ajustes → Contador de FPS → Probar el contador). */
    fun diagnose(ctx: Context, pkg: String?): String {
        val sb = StringBuilder()
        fun yn(b: Boolean): String = if (b) "sí" else "NO"
        val run = shizukuRunning()
        val gr = shizukuGranted()
        sb.append("Shizuku activo: ").append(yn(run)).append('\n')
        sb.append("Permiso de Shizuku: ").append(yn(gr)).append('\n')
        sb.append("Superposición sobre otras apps: ").append(yn(canOverlay(ctx))).append('\n')
        if (!run || !gr) {
            return sb.append("\nSin Shizuku activo y con permiso no se pueden leer los FPS.").toString()
        }
        val echo = sh("echo ok")?.trim()
        sb.append("Ejecutar comandos desde la app: ")
            .append(if (echo == "ok") "sí" else "NO (" + (echo ?: "sin respuesta") + ")").append('\n')
        if (echo != "ok") {
            return sb.append("\nShizuku responde, pero no deja ejecutar comandos desde esta app.").toString()
        }
        val p = probe()
        sb.append("Uso de GPU: ").append(p.first ?: "no encontrado en este equipo").append('\n')
        sb.append("Temperatura de CPU: ").append(p.second ?: "no encontrada").append('\n')
        if (pkg == null) {
            return sb.append("\nAbre un juego desde el launcher y vuelve a probar para revisar sus FPS.").toString()
        }
        val c = listLayers(pkg)
        sb.append("\nJuego: ").append(pkg).append('\n')
        if (c == null || c.isEmpty()) {
            return sb.append("Capas de dibujo: ninguna (¿sigue abierto el juego?)").toString()
        }
        sb.append("Capas de dibujo: ").append(c.size).append('\n')
        for (name in c.take(6)) {
            val f = measure(name)
            sb.append("• ").append(name.take(70)).append(" → ")
                .append(if (f != null) Math.round(f).toString() + " FPS" else "sin datos").append('\n')
        }
        val b = windowBounds(pkg)
        sb.append("Ventana del juego: ").append(b?.toShortString() ?: "no detectada").append('\n')
        return sb.toString()
    }
}
