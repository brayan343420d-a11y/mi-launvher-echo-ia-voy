package com.winlauncher

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import rikka.shizuku.Shizuku

/**
 * Contador de FPS de OTRA app. Android no deja medirlo sin permisos especiales, así que usa Shizuku
 * (permiso tipo "shell/adb") para leer `dumpsys SurfaceFlinger --latency` y lo dibuja en una
 * ventana flotante. Solo corre mientras el juego está abierto.
 */
object FpsMonitor {
    private val ui = Handler(Looper.getMainLooper())
    private var token = 0
    private var view: TextView? = null
    private var wm: WindowManager? = null

    fun shizukuRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) {
        false
    }

    fun shizukuGranted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    fun requestShizuku(code: Int) {
        try {
            Shizuku.requestPermission(code)
        } catch (_: Throwable) {
        }
    }

    fun canOverlay(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun ready(ctx: Context): Boolean = shizukuRunning() && shizukuGranted() && canOverlay(ctx)

    /** Debe llamarse desde el hilo principal. corner: 0 arriba-izq, 1 arriba-der, 2 abajo-izq, 3 abajo-der. */
    fun start(ctx: Context, pkg: String, corner: Int) {
        stop()
        if (!ready(ctx)) return
        showOverlay(ctx, corner)
        val my = token
        val t = Thread {
            var layer: String? = null
            var misses = 0
            var shown = false
            try {
                Thread.sleep(2500)
            } catch (_: InterruptedException) {
                return@Thread
            }
            while (token == my) {
                var fps: Float? = null
                if (layer == null) layer = pickLayer(pkg)
                val l = layer
                if (l != null) {
                    fps = measure(l)
                    if (fps == null) layer = null
                }
                if (fps != null) {
                    misses = 0
                    shown = true
                    val n = Math.round(fps)
                    ui.post {
                        if (token == my) view?.text = n.toString() + " FPS"
                    }
                } else {
                    misses++
                    if ((shown && misses >= 5) || (!shown && misses >= 40)) {
                        ui.post { if (token == my) stop() }
                        return@Thread
                    }
                }
                try {
                    Thread.sleep(1000)
                } catch (_: InterruptedException) {
                    return@Thread
                }
            }
        }
        t.isDaemon = true
        t.priority = Thread.MIN_PRIORITY
        t.start()
    }

    fun stop() {
        token++
        val v = view
        view = null
        if (v != null) {
            try {
                wm?.removeView(v)
            } catch (_: Exception) {
            }
        }
    }

    private fun showOverlay(ctx: Context, corner: Int) {
        val app = ctx.applicationContext
        val w = app.getSystemService(WindowManager::class.java)
        val d = app.resources.displayMetrics.density
        val tv = TextView(app)
        tv.text = "-- FPS"
        tv.setTextColor(0xFF7CFF7C.toInt())
        tv.textSize = 13f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
        val bg = GradientDrawable()
        bg.setColor(0x99000000.toInt())
        bg.cornerRadius = 6 * d
        tv.background = bg
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = when (corner) {
            1 -> Gravity.TOP or Gravity.END
            2 -> Gravity.BOTTOM or Gravity.START
            3 -> Gravity.BOTTOM or Gravity.END
            else -> Gravity.TOP or Gravity.START
        }
        lp.x = (10 * d).toInt()
        lp.y = (10 * d).toInt()
        try {
            w.addView(tv, lp)
            view = tv
            wm = w
        } catch (_: Exception) {
        }
    }

    // ───────────── medición ─────────────

    private val newProcess by lazy {
        try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            m
        } catch (_: Throwable) {
            null
        }
    }

    private fun sh(cmd: String): String? {
        return try {
            val m = newProcess ?: return null
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            try {
                p.waitFor()
            } catch (_: Exception) {
            }
            out
        } catch (_: Throwable) {
            null
        }
    }

    private fun quote(s: String): String =
        "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("$", "\\$").replace("`", "\\`") + "\""

    /** Busca la capa de SurfaceFlinger que de verdad dibuja el juego (la que más FPS reporta entre las candidatas). */
    private fun pickLayer(pkg: String): String? {
        val list = sh("dumpsys SurfaceFlinger --list") ?: return null
        val cands = list.lines()
            .map { it.trim() }
            .filter { it.contains(pkg) && !it.startsWith("Background for") && !it.startsWith("Bounds for") && !it.startsWith("Task=") }
        if (cands.isEmpty()) return null
        val ordered = cands.sortedBy {
            if (it.contains("SurfaceView") && it.contains("BLAST")) 0 else if (it.contains("SurfaceView")) 1 else 2
        }.take(4)
        var best: String? = null
        var bestFps = -1f
        for (c in ordered) {
            val f = measure(c) ?: continue
            if (f > bestFps) {
                bestFps = f
                best = c
            }
        }
        return best
    }

    private fun measure(layer: String): Float? {
        val out = sh("dumpsys SurfaceFlinger --latency " + quote(layer)) ?: return null
        val ts = ArrayList<Long>()
        val lines = out.lines()
        for (i in 1 until lines.size) {
            val parts = lines[i].trim().split(Regex("\\s+"))
            if (parts.size < 3) continue
            val t = parts[1].toLongOrNull() ?: continue
            if (t > 0L && t != Long.MAX_VALUE) ts.add(t)
        }
        if (ts.size < 2) return null
        ts.sort()
        val last = ts[ts.size - 1]
        if (System.nanoTime() - last > 2_000_000_000L) return 0f // capa parada
        val from = last - 1_000_000_000L
        val win = ts.filter { it >= from }
        if (win.size < 2) return 0f
        val span = (win[win.size - 1] - win[0]).toDouble()
        if (span <= 0.0) return 0f
        return ((win.size - 1) * 1_000_000_000.0 / span).toFloat()
    }
}
