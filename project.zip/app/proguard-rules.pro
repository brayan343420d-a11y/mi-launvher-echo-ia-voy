# Shizuku (se usa por reflexión para ejecutar comandos)
-keep class rikka.** { *; }
-keep class moe.shizuku.** { *; }
-dontwarn rikka.**
-dontwarn moe.shizuku.**
-dontwarn android.**
-ignorewarnings
